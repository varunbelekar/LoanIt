package com.lnt.loanApp.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.loanApp.entities.*;
import com.lnt.loanApp.exceptions.*;
import com.lnt.loanApp.services.*;



@Controller 
public class ControllerFinal {

	@Autowired
	private CustomerServices services;
     
	@RequestMapping("/applyHome")
	public ModelAndView applyHomeLoan() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("applyHome"); // creates a response that would be sent to browser
			return mAndV;
	}
	
	@RequestMapping("/landing")
	public ModelAndView homePage(
			) throws CustomerException {
	
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("landing"); // creates a response that would be sent to browser
		mAndV.addObject("now", "Home Page");
		
		return mAndV;
		
	}
	@RequestMapping("/landing1")
	public ModelAndView homePage1(			@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("message") String message
			) throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		System.out.println("message----->"+message);
		if(message!="")
		{  List<ContactUs> contactus=services.getContactUslist();
		int contactId=1;
		for(ContactUs y:contactus)
		{
			contactId=y.getContactId()+1;
			
		}
			ContactUs contactUs=new ContactUs();
			contactUs.setContactId(contactId);
			contactUs.setName(name);
			contactUs.setEmail(email);
			contactUs.setMessage(message);

			services.addContactUs(contactUs);
			System.out.println("contact us saved");
			mAndV.setViewName("landing");
		}
		else {
			mAndV.setViewName("landing1");
			mAndV.addObject("note", "Please enter some message");
		 // creates a response that would be sent to browser
		mAndV.addObject("now", "Home Page");
		}
		return mAndV;
		
	}

	@RequestMapping("/listAllCustomer")
	public ModelAndView getEmpList() throws CustomerException {
		List<Customer> custList = services.getCustomerList();

		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("ListAllCustomer");
		mAndV.addObject("empList", custList);
		mAndV.addObject("pageTitle", "List of all employee");
		return mAndV;
	}
    String email1;


	@RequestMapping("/login")
	public ModelAndView login() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("login"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "login Application");
		return mAndV;
	}
	
	
	@RequestMapping("/register")
	public ModelAndView register() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		
		mAndV.setViewName("register"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "register Application");
		return mAndV;
	}
	@RequestMapping("/loginAuthenticate" )
	public ModelAndView loginauthenticate( HttpServletRequest request,HttpServletResponse response,@RequestParam("email") String email,
			@RequestParam("password") String password) throws CustomerException, IOException {
		ModelAndView mAndV = new ModelAndView();
		System.out.println("in login");
		if(email.equals("admin@gmail.com") && password.equals("Newuser123"))
		{
			response.sendRedirect("adminPortal.do");
			//mAndV.setViewName("adminPortal");
		}
		else {
		Customer customer = services.getCustomerDetails(email, password);
		//System.out.println(customer.getName());
	
		//mAndV.setViewName("loginAuthenticate");

		if (customer != null) {
			
			
			request.setAttribute("email", email);
			email1=email;
			response.sendRedirect("customerProfile.do");
			//mAndV.setViewName("customerProfile"); 	
			mAndV.addObject("pageTitle", "Done");
			
			System.out.println("valid user");
		}
		else {
			mAndV.addObject("login", "Invalid Email or password");
			mAndV.setViewName("login"); 	
		
        System.out.println("invalid user");
		}}
		return mAndV;
	}
	
	@RequestMapping("/customerProfile")
	public ModelAndView customerProfile( HttpServletRequest request,HttpServletResponse response) throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		String aadhaar=null,accountNo=null;
		
		request.getAttribute("email");
		System.out.println(email1);
		mAndV.setViewName("customerProfile");
		List<Customer> customer=services.getCustomerListbymail(email1);
		List<CustomerLoan> customerLoan=services.getCustomerLoanList(email1);
		
		
		
		for(Customer c:customer)
		{
			mAndV.addObject("name", c.getName());	
			mAndV.addObject("email", c.getEmail());	
			mAndV.addObject("city", c.getCity());	
			mAndV.addObject("mobile", c.getMobile());	
			
		}
		for(CustomerLoan c: customerLoan)
		{
			mAndV.addObject("nameOfBorrower", c.getNameOfBorrower()); 
			mAndV.addObject("gender", c.getGender());
			String dateOfBirthtemp=c.getDob();
			String[] splited = dateOfBirthtemp.split("\\s+");
			System.out.println("splited--->"+splited[0]);
			String[] splited1 = splited[0].split("-");
			System.out.println("splited1--->"+splited1[1]);
			String dateOfBirth=splited1[2]+"-"+splited1[1]+"-"+splited1[0];
			System.out.println(dateOfBirth);
			mAndV.addObject("dob", dateOfBirth);
			mAndV.addObject("nationality", c.getNationality());
			mAndV.addObject("category", c.getCategory()); 
			mAndV.addObject("address", c.getAddress());
			mAndV.addObject("pincode", c.getPincode());
			mAndV.addObject("aadhaarNo", c.getAadhaarNo());
			mAndV.addObject("pan", c.getPan());
			mAndV.addObject("voterId", c.getVoterId());
			mAndV.addObject("applyAs", c.getApplyAs());
			mAndV.addObject("occupation", c.getOccupation());
			mAndV.addObject("designation", c.getDesignation());
			mAndV.addObject("nameOfOrg", c.getNameOfOrg());
			mAndV.addObject("addOfOrg", c.getAddOfOrg());
			mAndV.addObject("loanAmount", c.getLoanAmount());
			mAndV.addObject("tenure", c.getTenure());
		    aadhaar=c.getAadhaarNo();
		}
		List<Loan> loan=services.getLoanDetails(aadhaar);
		for(Loan l: loan)
		{
			mAndV.addObject("loanId", l.getLoanId());
			mAndV.addObject("loanType", l.getLoanType());
			mAndV.addObject("loanPrincipleAmount", l.getLoanPrincipleAmount());
			mAndV.addObject("loanCurrentAmount", l.getLoanCurrentAmount());
			mAndV.addObject("loanDate",l.getLoanDate());
			mAndV.addObject("accountNumber", l.getAccountNumber());
			mAndV.addObject("rateOfInterest", l.getRateOfInterest());
			
			accountNo=l.getAccountNumber();
		
			}
		List<CustomerAccount> customerAccount=services.getAccountDetails(accountNo);
		for(CustomerAccount c: customerAccount)
		{
			mAndV.addObject("ifscCode",c.getIfscCode());
			mAndV.addObject("bankName",c.getBankName());
			mAndV.addObject("salary",c.getSalary());
		
	
		}
		return mAndV;
	}
	@RequestMapping("/applyVehicle")
	public ModelAndView applyVehicle() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("applyVehicle"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "About Us");
		return mAndV;
	}
	@RequestMapping("/aboutUs")
	public ModelAndView aboutUs() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("aboutUs"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "About Us");
		return mAndV;
	}
	
	@RequestMapping("/terms")
	public ModelAndView terms() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("terms"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Terms and Conditions");
		return mAndV;
	}
	
	@RequestMapping("/underConstruction")
	public ModelAndView underConstruction() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("underConstruction"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Under Construction");
		return mAndV;
	}
	
	@RequestMapping("/statusNo")
	public ModelAndView statusNo() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("statusNo"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Not Eligible Status");
		return mAndV;
	}
	
	@RequestMapping("/statusYes")
	public ModelAndView statusYes() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("statusYes"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Eligible Status");
		return mAndV;
	}
	@RequestMapping("/notEligibleSalary")
	public ModelAndView notEligibleSalary() throws CustomerException {
		ModelAndView mAndV = new ModelAndView();
		mAndV.setViewName("notEligibleSalary"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Eligible Status");
		return mAndV;
	}
	


	@RequestMapping("/doneRegistration")
	public ModelAndView register(
			@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("city") String city,
			@RequestParam("mobile") String mobile,
			@RequestParam("password") String password
			) throws CustomerException {
		List<CustomerLoan> customerLoan=services.getCustomerLoanList(email);
		ModelAndView mAndV = new ModelAndView();
		boolean userExist=false;
		for(CustomerLoan cl: customerLoan)
		{
			if(email.equals(cl.getEmail()))
			{
				userExist=true;
			}
					
		}
		if(userExist)
		{
		Customer reg=new Customer();
		reg.setName(name);
		reg.setEmail(email);
		reg.setCity(city);
		reg.setMobile(mobile);
		reg.setPassword(password);
		services.insertCustomer(reg);
		mAndV.setViewName("login");
		}
			else {
		mAndV.addObject("error", "Please Enter the same Email Id provided at the time of applying for loan");
		mAndV.setViewName("register");
		}
		return mAndV;
	}
	
	@RequestMapping("/done")
	public ModelAndView authenticate(
			@RequestParam("name_of_borrower") String name_of_borrower,
			@RequestParam("gender") String gender,
			@RequestParam("dob") String dob,
			@RequestParam("nationality") String nationality,
			@RequestParam("category") String category,
			@RequestParam("address") String address,
			@RequestParam("pincode") Integer pincode,
			@RequestParam("mobile") String mobile,
			@RequestParam("aadhar") String aadhar,
			@RequestParam("pan") String pan,
			@RequestParam("voter_id") String voter_id,
			@RequestParam("email") String email,
			@RequestParam("apply_as") String apply_as,
			@RequestParam("occupation") String occupation,
			@RequestParam("designation") String designation,
			@RequestParam("name_of_org") String name_of_org,
			@RequestParam("add_of_org") String add_of_org,
			@RequestParam("loan_amount") String loan_amount,
			@RequestParam("tenure") Integer tenure,
			@RequestParam("account_number") String account_number,
			@RequestParam("ifsc_code") String ifsc_code,
			@RequestParam("bank_name") String bank_name,
			@RequestParam("salary") int salary,
			@RequestParam("loan_type") String loan_type,
			@RequestParam("roi") String roi
			) throws CustomerException {
		CustomerLoan customerLoan=new CustomerLoan();
		CustomerAccount customerAccount=new CustomerAccount();
		Loan loan=new Loan();
		customerLoan.setNameOfBorrower(name_of_borrower);
		customerLoan.setGender(gender);
		customerLoan.setDob(dob);
		customerLoan.setNationality(nationality);
		customerLoan.setCategory(category);
		customerLoan.setAddress(address);
		customerLoan.setPincode(pincode);
		customerLoan.setMobile(mobile);
		customerLoan.setAadhaarNo(aadhar);
		customerLoan.setPan(pan);
		customerLoan.setVoterId(voter_id);
		customerLoan.setEmail(email);
		customerLoan.setApplyAs(apply_as);
		customerLoan.setOccupation(occupation);
		customerLoan.setDesignation(designation);
		customerLoan.setNameOfOrg(name_of_org);
		customerLoan.setAddOfOrg(add_of_org);
		customerLoan.setLoanAmount(loan_amount);
		customerLoan.setTenure(tenure);
		
		customerAccount.setAccountNumber(account_number);
		customerAccount.setIfscCode(ifsc_code);
		customerAccount.setBankName(bank_name);
		customerAccount.setSalary(salary);
		
		loan.setLoanType(loan_type);
		loan.setLoanPrincipleAmount(loan_amount); 	
		loan.setLoanCurrentAmount(loan_amount);
	        Date d=new Date();
	      String strDateFormat="dd-MMM-yyyy";
	      SimpleDateFormat objSDF= new SimpleDateFormat(strDateFormat);
	        System.out.println(objSDF.format(d));
	        loan.setLoanDate(objSDF.format(d));
		List<Loan> x=services.getloanIdList();
		int loanId=1;
		for(Loan y:x)
		{
			loanId=y.getLoanId()+1;
			
		}
		System.out.println(account_number);
		
		loan.setLoanId(loanId);
		loan.setAadhaar(aadhar);   
		loan.setAccountNumber(account_number);
		loan.setAccountNumber(account_number);
		int i = Integer.parseInt(roi);
		loan.setRateOfInterest(i);
		loan.setTenure(tenure);
		System.out.println("Loan details from controller--->"+loan);
		ModelAndView mAndV = new ModelAndView();
		if(services.aadhaarVerification(customerLoan))
		{ 
			int loanAmountInt= Integer.parseInt(loan_amount);
			if((salary>300000 && salary<=600000 && loanAmountInt<=400000 ) || (salary>600000 && salary<=1000000 && loanAmountInt<=600000 )
					||(salary>1000000 && salary<=1400000 && loanAmountInt<=800000 )||(salary>1400000 && loanAmountInt<=1200000 ))
					 {
		services.insertCustomerLoan(customerLoan);
		services.insertCustomerAccount(customerAccount);
		services.insertLoan(loan);
		
		mAndV.setViewName("statusYes"); 
		}
			else {
				mAndV.setViewName("notEligibleSalary"); 
			}	
		}
		else {
			
			mAndV.setViewName("statusNo"); 	
		}
		System.out.println(services.aadhaarVerification(customerLoan));
		
		System.out.println("in authenticate");
		
		mAndV.addObject("pageTitle", "Registered");
	
		
		return mAndV;
	}
	@RequestMapping("/adminPortal")
	public ModelAndView adminPortal() throws CustomerException {
		String cDate=null; //CurrentDate
		String lDate=null; //LoanDate
		String currentAmount=null;
		int loanId=0;
		double emi;
		ArrayList<Object> al=new ArrayList<Object>();
		ArrayList<Object> al2=new ArrayList<Object>();
		ModelAndView mAndV = new ModelAndView();
		List<CustomerLoan> allCustomers=services.getCustomerLoanList();
		for(CustomerLoan x: allCustomers)
		{ 
			
			Object[] arr = new Object[100];
			arr[0]= x.getNameOfBorrower();
			arr[1]=x.getEmail();
			System.out.println("Admin-aadhar->"+x.getAadhaarNo());
			List<Loan> loan=services.getLoanDetails(x.getAadhaarNo());
			for(Loan y:loan)
			{ 
				arr[2]=y.getAccountNumber();
				arr[3]=y.getLoanType();
				arr[4]=y.getLoanDate();
				arr[5]=y.getLoanPrincipleAmount();
				arr[6]=y.getLoanCurrentAmount();
				emi=emiCalculate(Double.parseDouble(y.getLoanPrincipleAmount()),y.getRateOfInterest(),y.getTenure());	
			}
			al.add(arr);
			System.out.println(arr);
			
		}
		for(CustomerLoan x: allCustomers)
		{  
			
			Object[] arr = new Object[100];
			arr[0]= x.getNameOfBorrower();
			arr[1]=x.getEmail();
			System.out.println("Admin-aadhar->"+x.getAadhaarNo());
			List<Loan> loan=services.getLoanDetails(x.getAadhaarNo());
			for(Loan y:loan)
			{
				  loanId=y.getLoanId();
				int i=y.getTenure();
				double currentAmt=Double.parseDouble(y.getLoanCurrentAmount());
				double principleAmountFloat=Double.parseDouble(y.getLoanPrincipleAmount());
				double rateOfInterest=(double) y.getRateOfInterest();
				double x1=emiCalculate(principleAmountFloat,rateOfInterest,i);
				
				double updatedCurrentAmount=currentAmt-x1;
				System.out.println("CurrentAmt = "+currentAmt);
				System.out.println("EMI = "+x1);
				System.out.println("Updated Current Ammount = "+updatedCurrentAmount);
				currentAmount =  String.valueOf(updatedCurrentAmount);
				Date d=new Date();
				  String strDateFormat="yyyy-MM-dd";
			      SimpleDateFormat objSDF= new SimpleDateFormat(strDateFormat);
			     String loanDatex=y.getLoanDate();
			    String[] loanDate = loanDatex.split("\\s+");
			    lDate=loanDate[0];
			    cDate=objSDF.format(d);
			      System.out.println("Getting date "+loanDate[0]);
				System.out.println("Today is "+objSDF.format(d));
				arr[2]=y.getAccountNumber();
				arr[3]=y.getLoanType();
				arr[4]=y.getLoanDate();
				arr[5]=y.getLoanPrincipleAmount();
				arr[6]=y.getLoanCurrentAmount();
				}
			String[] splited1 = lDate.split("-");
			String[] splited2 = cDate.split("-");
			
			
			if(splited1[2].equals(splited2[2]) && splited1[1].equals(splited2[1]))
			{
				
				al2.add(arr);	
				services.updateCurrentAmmount(currentAmount, loanId);
			}
			else {
				
				mAndV.addObject("CustomerDue", "No Customer found having EMI due today");
			}
			
			//al2.add(arr);	
			//services.updateCurrentAmmount(currentAmount, loanId);
			/*services.updateCurrentAmmount(currentAmount, loanId);
			services.updateCurrentAmmount(currentAmount, loanId);*/
			System.out.println(arr);
			
		}
		mAndV.addObject("allCustomers",al);
		mAndV.addObject("allCustomersDue",al2);
		mAndV.setViewName("adminPortal"); // creates a response that would be sent to browser
		mAndV.addObject("pageTitle", "Admin Portal");
		return mAndV;
	}
		
	public double emiCalculate(double principle, double ratePerAnnum, int time)
	{
		double result=0.0, ratePerMonth = 0.0;
		ratePerMonth= ratePerAnnum/(12*100);
		System.out.println(ratePerMonth);
		result = (principle*ratePerMonth*(Math.pow((1+ratePerMonth),time))/((Math.pow((1+ratePerMonth), time))-1));
		return result;
		
	}
}


