package com.lnt.loanApp.daos;



import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.loanApp.entities.AadhaarVerification;
import com.lnt.loanApp.entities.ContactUs;
import com.lnt.loanApp.entities.Customer;
import com.lnt.loanApp.entities.CustomerAccount;
import com.lnt.loanApp.entities.CustomerLoan;
import com.lnt.loanApp.entities.Loan;
import com.lnt.loanApp.exceptions.CustomerException;



@Repository("CustomerDao")
public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
    private  SessionFactory factory;

	@Override
	public void addCustomerDetails(Customer customerObj)
	{
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(customerObj);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				System.out.println("error "+ e.getMessage());
				tn.rollback();
			}
		}
		session.close();
	}
	
	@Override
	public List<Customer> getCustomerList() throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from Customer");
		List<Customer> list=query.list();
		session.close();
		return list;
	}
	@Override
	public List<CustomerLoan> getCustomerLoanList() throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from CustomerLoan");
		List<CustomerLoan> list=query.list();
		session.close();
		return list;
	}
	@Override
	public List<AadhaarVerification> getAadhaarList() throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from AadhaarVerification");
		List<AadhaarVerification> list=query.list();
		session.close();
		return list;
	}

	@Override
	public List<Customer> getCustomerDetails(String email) throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from Customer c where c.email = '"+email+"'");
		List<Customer> list=query.list();
		session.close();
		return list;
		
		
	}

	@Override
	public List<CustomerLoan> getCustomerLoanDetails(String email) throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from CustomerLoan c where c.email = '"+email+"'");
		List<CustomerLoan> list=query.list();
		session.close();
		return list;
		
		
	}
	@Override
	public List<Loan> getLoanDetails(String aadhaar) throws CustomerException {
		System.out.println("In dao impl");
		Session session = factory.openSession();
		Query query= session.createQuery("from Loan c where c.aadhaar = '"+aadhaar+"'");
		List<Loan> list=query.list();
		for(Loan x:list)
		{
			
			System.out.println("Getting current amt from DAO ="+x.getLoanCurrentAmount());
			
		}
		session.close();
		return list;
		
		
	}
	@Override
	public List<CustomerAccount> getAccountDetails(String accountNumber) throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from CustomerAccount c where c.accountNumber = '"+accountNumber+"'");
		List<CustomerAccount> list=query.list();
		session.close();
		return list;
		
		
	}

	@Override
	public List<Loan> getloanlist() throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from Loan l order by l.loanId");
		List<Loan> list=query.list();
		session.close();
		return list;
		
		
	}
	@Override
	public List<ContactUs> getContactUslist() throws CustomerException {
		Session session = factory.openSession();
		Query query= session.createQuery("from ContactUs l order by l.contactId");
		List<ContactUs> list=query.list();
		session.close();
		return list;
		
		
	}
	@Override
	public void updateCurrentAmmount(String currentAmount,int loanId) throws CustomerException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			Loan loan=(Loan) session.get(Loan.class, loanId);
			String query="update Loan l set l.loanCurrentAmount = :newbal where l.loanId = :lId";
			
			Query sql=session.createQuery(query);
			sql.setParameter("newbal", currentAmount);
			sql.setParameter("lId", loanId);
			sql.executeUpdate();
			tn.commit();
	System.out.println("Current balance is updated");
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				 e.printStackTrace();
				tn.rollback();
			}
		}
		session.close();
	
		
	}
	@Override
	public void addCustomerloanDetails(CustomerLoan customerLoan)  
{
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(customerLoan);
			tn.commit();
	
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				 e.printStackTrace();
				tn.rollback();
			}
		}
		session.close();
	}
	
	@Override
	public void addContactUs(ContactUs contactUs)  
{
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(contactUs);
			tn.commit();
	
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				 e.printStackTrace();
				tn.rollback();
			}
		}
		session.close();
	}
	
	@Override
	public void addLoanDetails(Loan ld)  
{		System.out.println("Loan Details: " + ld);
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.save(ld);
			tn.commit();
	
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				 e.printStackTrace();
				tn.rollback();
			}
		}
		session.close();
	}
	
	@Override
	public void addAccountDetails(CustomerAccount acc)  
{
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(acc);
			tn.commit();
	
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				 e.printStackTrace();
				tn.rollback();
			}
		}
		session.close();
	}


	
	@Override
	public boolean aadhaarVerification(CustomerLoan customerLoan) throws CustomerException {
		//AadhaarVerification av=new AadhaarVerification();
		boolean r=false;
		List<AadhaarVerification> aadhaarVerification=getAadhaarList();
		String name=customerLoan.getNameOfBorrower();
		String aadharNo= customerLoan.getAadhaarNo();
	      for(AadhaarVerification x:aadhaarVerification)
	      {
	    	  if(x.getAadhaarName().equalsIgnoreCase(name) && x.getAadhaarId().equalsIgnoreCase(aadharNo))
	    	  {
	    		  r=true;
	    	  }
	      }
return r;
}

}