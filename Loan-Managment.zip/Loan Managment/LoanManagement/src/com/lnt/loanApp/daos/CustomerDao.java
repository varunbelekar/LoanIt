package com.lnt.loanApp.daos;
import java.util.List;

import com.lnt.loanApp.entities.AadhaarVerification;
import com.lnt.loanApp.entities.ContactUs;
import com.lnt.loanApp.entities.Customer;
import com.lnt.loanApp.entities.CustomerAccount;
import com.lnt.loanApp.entities.CustomerLoan;
import com.lnt.loanApp.entities.Loan;
import com.lnt.loanApp.exceptions.CustomerException;


public interface CustomerDao {
	
	List<Customer> getCustomerList() throws CustomerException;
	List<Customer> getCustomerDetails(String emailId) throws CustomerException;
	void addCustomerDetails(Customer cust);
	void addCustomerloanDetails(CustomerLoan loan);
	void addLoanDetails(Loan ld);
	void addAccountDetails(CustomerAccount acc);
	List<Loan> getloanlist() throws CustomerException;
	boolean aadhaarVerification(CustomerLoan cl) throws CustomerException ;
	List<AadhaarVerification> getAadhaarList() throws CustomerException;
	List<CustomerLoan> getCustomerLoanDetails(String email) throws CustomerException;
	List<Loan> getLoanDetails(String aadhaar) throws CustomerException;
	List<CustomerAccount> getAccountDetails(String accountNumber) throws CustomerException;
	void addContactUs(ContactUs contactUs);
	List<ContactUs> getContactUslist() throws CustomerException;
	void updateCurrentAmmount(String currentAmount, int loanId) throws CustomerException;
	List<CustomerLoan> getCustomerLoanList() throws CustomerException;
	
	
}
