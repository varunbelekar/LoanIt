package com.lnt.loanApp.entities;


public class AadhaarVerification {
	
	private String aadhaarId;

		private String aadhaarName;
	
		private String aadhaarDOB;

		private String aadhaarAddress;
		public AadhaarVerification(){}
		
	public String getAadhaarId() {
		return aadhaarId;
	}
	public void setAadhaarId(String aadhaarId) {
		this.aadhaarId = aadhaarId;
	}
	public String getAadhaarName() {
		return aadhaarName;
	}
	public void setAadhaarName(String aadhaarName) {
		this.aadhaarName = aadhaarName;
	}
	public String getAadhaarDOB() {
		return aadhaarDOB;
	}
	public void setAadhaarDOB(String aadhaarDOB) {
		this.aadhaarDOB = aadhaarDOB;
	}
	public String getAadhaarAddress() {
		return aadhaarAddress;
	}
	public void setAadhaarAddress(String aadhaarAddress) {
		this.aadhaarAddress = aadhaarAddress;
	}
	@Override
	public String toString() {
		return "AadhaarVerification [aadhaarId=" + aadhaarId + ", aadhaarName=" + aadhaarName + ", aadhaarDOB="
				+ aadhaarDOB + ", aadhaarAddress=" + aadhaarAddress + "]";
	}
	public AadhaarVerification(String aadhaarId, String aadhaarName, String aadhaarDOB, String aadhaarAddress) {
		super();
		this.aadhaarId = aadhaarId;
		this.aadhaarName = aadhaarName;
		this.aadhaarDOB = aadhaarDOB;
		this.aadhaarAddress = aadhaarAddress;
	}
	 
	 
}
