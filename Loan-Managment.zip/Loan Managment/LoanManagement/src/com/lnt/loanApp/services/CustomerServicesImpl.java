package com.lnt.loanApp.services;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.loanApp.daos.CustomerDao;
import com.lnt.loanApp.daos.CustomerDaoImpl;
import com.lnt.loanApp.entities.ContactUs;
import com.lnt.loanApp.entities.Customer;
import com.lnt.loanApp.entities.CustomerAccount;
import com.lnt.loanApp.entities.CustomerLoan;
import com.lnt.loanApp.entities.Loan;
import com.lnt.loanApp.exceptions.CustomerException;
@Service("CustomerServices")
public class CustomerServicesImpl implements CustomerServices {
	 @Autowired
		private CustomerDao dao;
	  public CustomerServicesImpl() throws CustomerException{
		  dao = new CustomerDaoImpl();
	  }
		@Override
		public List<CustomerLoan> getCustomerLoanList() throws CustomerException {
			return dao.getCustomerLoanList();
		}
	  
	@Override
	public void insertCustomer(Customer customerObj) throws CustomerException {
		dao.addCustomerDetails(customerObj);
			
		}
	@Override
	public List<Customer> getCustomerList() throws CustomerException {
		 
		return dao.getCustomerList();
	}
	@Override
	public void insertCustomerLoan(CustomerLoan customerLoan) throws CustomerException {
		 
		 dao.addCustomerloanDetails(customerLoan);
	}

	@Override
	public void insertLoan(Loan loan) throws CustomerException {
		 
		 dao.addLoanDetails(loan);
	}
	@Override
	public void insertCustomerAccount(CustomerAccount customerAccount) throws CustomerException {
		dao.addAccountDetails(customerAccount);
	}
	@Override
	public List<Loan> getloanIdList() throws CustomerException {
		 
		return dao.getloanlist();
	}
	@Override
	public List<Loan> getMaxloanIdList() throws CustomerException {
		return dao.getloanlist();
	}
	@Override
	public boolean aadhaarVerification(CustomerLoan customerLoan) throws CustomerException {
		return dao.aadhaarVerification(customerLoan);
	}
	@Override
	public List<CustomerLoan> getCustomerLoanList(String email) throws CustomerException {
		 
		return dao.getCustomerLoanDetails(email);
	}
	@Override
	public List<Customer> getCustomerListbymail(String email) throws CustomerException {
		 
		return dao.getCustomerDetails(email);
	}
	@Override
	public List<Loan> getLoanDetails(String aadhaar) throws CustomerException {
		
		return dao.getLoanDetails(aadhaar);
		
		
	}
	@Override
	public List<CustomerAccount> getAccountDetails(String accountNumber) throws CustomerException {
		
		return dao.getAccountDetails(accountNumber);
		
		
	}
	@Override
	public void addContactUs(ContactUs contactUs)  
{  
		dao.addContactUs(contactUs);
}
	@Override
	public List<ContactUs> getContactUslist() throws CustomerException {
	return dao.getContactUslist();
	}
	@Override
	public void updateCurrentAmmount(String currentAmount,int loanId) throws CustomerException {
	dao.updateCurrentAmmount(currentAmount, loanId);
	}
	

	@Override
	public Customer getCustomerDetails(String email,String password) throws CustomerException {
		Customer customer=null;

		List<Customer> customerDetail = dao.getCustomerDetails(email);
		for(Customer cust: customerDetail)
		{
			String pass = cust.getPassword();
			String emailid = cust.getEmail(); 
			
			if(email.equalsIgnoreCase(emailid) && password.equals(pass))
			{
				customer=cust;
				
			} 
			else
			{	
				customer=null;
			}
			
					}
		return customer;
		
	}
}

