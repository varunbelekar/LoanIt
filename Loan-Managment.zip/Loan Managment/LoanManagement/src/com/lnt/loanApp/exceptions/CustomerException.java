package com.lnt.loanApp.exceptions;

public class CustomerException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public CustomerException(String message) {
		super(message);
		
	}
	//Exception Chaining
	public CustomerException(String message, Throwable cause) {
		super(message, cause);
		
	}

}
