package com.loan.dao;

import com.loan.model.Person;

public interface PersonalDao {

	public void addPerson(Person person) throws Exception;
}
