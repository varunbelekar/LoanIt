package com.loan.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import com.loan.model.HLoanDetails;

public class HLoanDetailsDAOImpl implements HLoanDetailsDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addHLoanDetails(HLoanDetails hLoanDetails) throws Exception {
		
		sessionFactory.getCurrentSession().saveOrUpdate(hLoanDetails);


	}

	@Override
	@SuppressWarnings("unchecked")
	public List<HLoanDetails> listHLoanDetails() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in dao");
		return (List<HLoanDetails>) sessionFactory.getCurrentSession().createCriteria(HLoanDetails.class).list();
	}

}
