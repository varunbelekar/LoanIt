package com.loan.dao;

import java.util.List;

import com.loan.model.Vehicle;


public interface VehicleDAO {
	
public void addVehicle(Vehicle vehicle) throws Exception;
	
	public List<Vehicle> listVehicle() throws Exception;


}
