package com.loan.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.loan.model.Employment;

public class EmploymentDAOImpl implements EmploymentDAO {

	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	public void addEmployment(Employment employment) throws Exception {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(employment);

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Employment> listEmployment() throws Exception {
		// TODO Auto-generated method stub
		return (List<Employment>) sessionFactory.getCurrentSession().createCriteria(Employment.class).list();


	}

}
