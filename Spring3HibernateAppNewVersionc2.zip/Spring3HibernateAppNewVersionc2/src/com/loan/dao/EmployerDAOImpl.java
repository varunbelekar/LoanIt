package com.loan.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.loan.model.Employer;

public class EmployerDAOImpl implements EmployerDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addEmployer(Employer employer) throws Exception {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(employer);
		System.out.println("hii dao");


	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Employer> listEmployer() throws Exception {
		// TODO Auto-generated method stub
		return (List<Employer>) sessionFactory.getCurrentSession().createCriteria(Employer.class).list();	}

}

