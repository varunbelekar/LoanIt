package com.loan.dao;

import java.util.List;

import com.loan.model.Document;

public interface DocumentDao {
public void save(Document document);
	
	
	public List<Document> list();
	
	
	public Document get(Integer id);

	
	public void remove(Integer id);
}
