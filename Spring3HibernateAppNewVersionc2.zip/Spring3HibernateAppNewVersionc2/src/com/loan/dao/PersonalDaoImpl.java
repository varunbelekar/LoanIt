package com.loan.dao;

import org.hibernate.SessionFactory;

import com.loan.model.Person;


public class PersonalDaoImpl implements PersonalDao {

private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	@Override
	public void addPerson(Person person) throws Exception {
		sessionFactory.getCurrentSession().saveOrUpdate(person);
	}

}
