package com.loan.bean;

public class HLoanDetailsBean {
	
	private Integer hloanId;
	private Integer hloanAmount;
	private Integer costOfProperty;
	private Integer tenure;
	private String hrepayment;
	private Integer hinterest;
	private String typeLoan;
	private String status="pending";
	private Integer id;
	
	
	

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	
	public Integer getHloanId() {
		return hloanId;
	}
	public void setHloanId(Integer hloanId) {
		this.hloanId = hloanId;
	}
	
	public Integer getHloanAmount() {
		return hloanAmount;
	}
	public void setHloanAmount(Integer hloanAmount) {
		this.hloanAmount = hloanAmount;
	}
	
	public Integer getCostOfProperty() {
		return costOfProperty;
	}
	public void setCostOfProperty(Integer costOfProperty) {
		this.costOfProperty = costOfProperty;
	}
	public String getHrepayment() {
		return hrepayment;
	}
	public void setHrepayment(String hrepayment) {
		this.hrepayment = hrepayment;
	}
	public Integer getHinterest() {
		return hinterest;
	}
	public void setHinterest(Integer hinterest) {
		this.hinterest = hinterest;
	}
	
	public String getTypeLoan() {
		return typeLoan;
	}
	public void setTypeLoan(String typeLoan) {
		this.typeLoan = typeLoan;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	

}
