package com.loan.bean;

public class PropertyBean {
	
	private Integer npropertyId;
	private String builderName;
	private String regOwner;
	private String address;
	private float landArea;
	private float builtupArea;
	private String typeProperty;
	private String usesProperty;
	private Integer id;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getNpropertyId() {
		return npropertyId;
	}
	public void setNpropertyId(Integer npropertyId) {
		this.npropertyId = npropertyId;
	}
	public String getBuilderName() {
		return builderName;
	}
	public void setBuilderName(String builderName) {
		this.builderName = builderName;
	}
	public String getRegOwner() {
		return regOwner;
	}
	public void setRegOwner(String regOwner) {
		this.regOwner = regOwner;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getLandArea() {
		return landArea;
	}
	public void setLandArea(float landArea) {
		this.landArea = landArea;
	}
	public float getBuiltupArea() {
		return builtupArea;
	}
	public void setBuiltupArea(float builtupArea) {
		this.builtupArea = builtupArea;
	}
	public String getTypeProperty() {
		return typeProperty;
	}
	public void setTypeProperty(String typeProperty) {
		this.typeProperty = typeProperty;
	}
	public String getUsesProperty() {
		return usesProperty;
	}
	public void setUsesProperty(String usesProperty) {
		this.usesProperty = usesProperty;
	}
	
	
	

}
