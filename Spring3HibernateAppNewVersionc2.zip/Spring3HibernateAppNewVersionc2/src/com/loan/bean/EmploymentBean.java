package com.loan.bean;

public class EmploymentBean {
	
		
		private Long employmentDetailsId;
		private String applyingAs;
		private String salaried;
		private String natureOfOrganization;
		private String occupation;
		private String designation;
		private Long monthlyIncome;
		private Integer id;
		
		
		

		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public Long getEmploymentDetailsId() {
			return employmentDetailsId;
		}
		public void setEmploymentDetailsId(Long employmentDetailsId) {
			this.employmentDetailsId = employmentDetailsId;
		}
		public String getApplyingAs() {
			return applyingAs;
		}
		public void setApplyingAs(String applyingAs) {
			this.applyingAs = applyingAs;
		}
		public String getSalaried() {
			return salaried;
		}
		public void setSalaried(String salaried) {
			this.salaried = salaried;
		}
		public String getNatureOfOrganization() {
			return natureOfOrganization;
		}
		public void setNatureOfOrganization(String natureOfOrganization) {
			this.natureOfOrganization = natureOfOrganization;
		}
		public String getOccupation() {
			return occupation;
		}
		public void setOccupation(String occupation) {
			this.occupation = occupation;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public Long getMonthlyIncome() {
			return monthlyIncome;
		}
		public void setMonthlyIncome(Long monthlyIncome) {
			this.monthlyIncome = monthlyIncome;
		}
		
		

}
