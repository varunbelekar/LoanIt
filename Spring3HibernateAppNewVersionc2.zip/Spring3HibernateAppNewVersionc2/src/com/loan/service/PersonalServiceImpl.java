package com.loan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.PersonalDao;
import com.loan.model.Person;


@Service("personalService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class PersonalServiceImpl implements PersonalService {

	@Autowired
	private PersonalDao personalDao;
	
	public void setPersonalDao(PersonalDao personalDao) {
		this.personalDao = personalDao;
	}



	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addPerson(Person person) throws Exception {
		personalDao.addPerson(person);
	}

}
