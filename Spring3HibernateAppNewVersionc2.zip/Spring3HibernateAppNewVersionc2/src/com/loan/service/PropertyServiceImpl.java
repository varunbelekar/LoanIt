package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.PropertyDAO;
import com.loan.model.Property;


@Service("propertyService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class PropertyServiceImpl implements PropertyService {
	
	@Autowired
	private PropertyDAO propertyDAO;
	
	public void setPropertyDAO(PropertyDAO propertyDAO) {
		this.propertyDAO = propertyDAO;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addPropertyService(Property property) throws Exception {
		// TODO Auto-generated method stub
		propertyDAO.addProperty(property);

	}

	@Override
	public List<Property> listPropertyService() throws Exception {
		// TODO Auto-generated method stub
		return propertyDAO.listProperty();
	}

}
