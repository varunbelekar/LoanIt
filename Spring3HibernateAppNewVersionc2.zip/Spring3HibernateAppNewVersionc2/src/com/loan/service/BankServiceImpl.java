package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.BankDAO;
import com.loan.model.Bank;
@Service("bankService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class BankServiceImpl implements BankService {

	@Autowired
	private BankDAO bankDao;
	
	public void setBankDao(BankDAO bankDao) {
		this.bankDao = bankDao;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addBankService(Bank bank) throws Exception {
		// TODO Auto-generated method stub
		bankDao.addBank(bank);
	}

	@Override
	public List<Bank> listBankService() throws Exception {
		// TODO Auto-generated method stub
		return bankDao.listBank();
	}

}
