package com.loan.service;



import com.loan.model.Person;

public interface PersonalService {

	public void addPerson(Person person) throws Exception;
}
