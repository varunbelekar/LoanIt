package com.loan.service;

import java.util.List;

import com.loan.model.Property;


public interface PropertyService {
	
	public void addPropertyService(Property property) throws Exception;
	
	public List<Property> listPropertyService() throws Exception;

}
