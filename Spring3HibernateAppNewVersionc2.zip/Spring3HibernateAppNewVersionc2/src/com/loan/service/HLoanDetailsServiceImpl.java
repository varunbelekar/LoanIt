package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.HLoanDetailsDAO;
import com.loan.model.HLoanDetails;


@Service("hLoanDetailsService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class HLoanDetailsServiceImpl implements HLoanDetailsService {
	
	@Autowired
	private HLoanDetailsDAO hLoanDetailsDAO;
	
	public void sethLoanDetailsDAO(HLoanDetailsDAO hLoanDetailsDAO) {
		this.hLoanDetailsDAO = hLoanDetailsDAO;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addHLoanDetailsService(HLoanDetails hLoanDetails) throws Exception {
		
		hLoanDetailsDAO.addHLoanDetails(hLoanDetails);

	}

	@Override
	public List<HLoanDetails> listHLoanDetailsService() throws Exception {
		System.out.println("in service");
		return hLoanDetailsDAO.listHLoanDetails();
	}

}
