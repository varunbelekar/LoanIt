package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.EmploymentBean;
import com.loan.model.Employment;
import com.loan.service.EmploymentService;

@Controller
public class EmploymentController {
	
	@Autowired
	private EmploymentService employmentService;
	
		
	public void setEmploymentService(EmploymentService employmentService) {
		this.employmentService = employmentService;
	}

	@RequestMapping(value = "/save1", method = RequestMethod.POST)
	public ModelAndView saveEmployment(@ModelAttribute("command") EmploymentBean employmentBean, 
			BindingResult result,HttpServletRequest request)
	{
		
		Integer v = (Integer)request.getSession().getAttribute("id");
		employmentBean.setId(v);
		
		Employment employment = prepareModel(employmentBean);
		
		try
		{
			employmentService.addEmploymentService(employment);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/add.html");
	}

	@RequestMapping(value="/listEmployment", method = RequestMethod.GET)
	public ModelAndView listEmployment() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("employments", prepareListofBean(employmentService.listEmploymentService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("employmentListForm", model);
	}

	@RequestMapping(value = "/add1", method = RequestMethod.GET)
	public ModelAndView addEmployment(@ModelAttribute("command")  EmploymentBean employmentBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("employments",  prepareListofBean(employmentService.listEmploymentService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addEmploymentForm", model);
	}
	

	
	private Employment prepareModel(EmploymentBean employmentBean){
		Employment employment = new Employment();
		employment.setCapplyingAs(employmentBean.getApplyingAs());
		employment.setCdesignation(employmentBean.getDesignation());
		employment.setCemploymentDetailsId(employmentBean.getEmploymentDetailsId());
		employment.setCmonthlyIncome(employmentBean.getMonthlyIncome());
		employment.setCnatureOfOrganization(employmentBean.getNatureOfOrganization());
		employment.setCoccupation(employmentBean.getOccupation());
		employment.setCsalaried(employmentBean.getSalaried());
		employment.setId(employmentBean.getId());

		return employment;
	}
	
	
	private List<EmploymentBean> prepareListofBean(List<Employment> employments){
		List<EmploymentBean> beans = null;
		if(employments != null && !employments.isEmpty()){
			beans = new ArrayList<EmploymentBean>();
			EmploymentBean bean = null;
			for(Employment employment : employments){
				bean = new EmploymentBean();
				bean.setApplyingAs(employment.getCapplyingAs());
				bean.setDesignation(employment.getCdesignation());
				bean.setEmploymentDetailsId(employment.getCemploymentDetailsId());
				bean.setMonthlyIncome(employment.getCmonthlyIncome());
				bean.setNatureOfOrganization(employment.getCnatureOfOrganization());
				bean.setOccupation(employment.getCoccupation());
				bean.setSalaried(employment.getCsalaried());
				bean.setId(employment.getId());
				beans.add(bean);
			}
		}
		return beans;
	}
	
	
	


}
