package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.BankBean;
import com.loan.model.Bank;
import com.loan.service.BankService;
@Controller
public class BankController {
	@Autowired
	private BankService bankService;

	public void setBankService(BankService bankService) {
		this.bankService = bankService;
	}
	
	
	@RequestMapping(value = "/bank1", method = RequestMethod.POST)
	public ModelAndView saveBank(@ModelAttribute("command") BankBean bankBean, 
			BindingResult result,HttpServletRequest request) {
		
		Integer v = (Integer)request.getSession().getAttribute("id");
		bankBean.setId(v);
		Bank bank = prepareModel(bankBean);
		try
		{
			bankService.addBankService(bank);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/padd.html");
	}
	
	
	@RequestMapping(value="/listBank", method = RequestMethod.GET)
	public ModelAndView listBank() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("banks", prepareListofBean(bankService.listBankService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("bankListForm", model);
	}
	
	
	@RequestMapping(value = "/addbank", method = RequestMethod.GET)
	public ModelAndView addBank(@ModelAttribute("command")BankBean bankBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("banks",  prepareListofBean(bankService.listBankService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addBankForm", model);
	}
	
	
	private Bank prepareModel(BankBean bankBean){
		Bank bank = new Bank();
		bank.setCaccountNo(bankBean.getAccountNo());
		bank.setCbankId(bankBean.getBankId());
		bank.setcIfscCode(bankBean.getIfscCode());
		bank.setCnameOfBank(bankBean.getNameOfBank());
		bank.setId(bankBean.getId());
		
		return bank;
	}
	
	
	private List<BankBean> prepareListofBean(List<Bank> banks){
		List<BankBean> beans = null;
		if(banks != null && !banks.isEmpty()){
			beans = new ArrayList<BankBean>();
			BankBean bean = null;
			for(Bank bank : banks){
				bean = new BankBean();
				bean.setAccountNo(bank.getCaccountNo());
				bean.setBankId(bank.getCbankId());
				bean.setIfscCode(bank.getcIfscCode());
				bean.setNameOfBank(bank.getCnameOfBank());
				bean.setId(bank.getId());
				
				beans.add(bean);
			}
		}
		return beans;
	}
	
}
