package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.VehicleBean;
import com.loan.model.Vehicle;
import com.loan.service.VehicleService;

@Controller
public class VehicleController {
	
	@Autowired
	private VehicleService vehicleService;

	public void setVehicleservice(VehicleService vehicleService) {
		this.vehicleService = vehicleService;
	}
	
	
	@RequestMapping(value = "/vsave", method = RequestMethod.POST)
	public ModelAndView saveVehicle(@ModelAttribute("command") VehicleBean vehicleBean ,
			BindingResult result,HttpServletRequest request) {
		
		Integer v = (Integer)request.getSession().getAttribute("id1");
		vehicleBean.setId(v);
		
		Vehicle vehicle = prepareModel(vehicleBean);
		try
		{
			vehicleService.addVehicleService(vehicle);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/vadd1.html");
	}
	
	@RequestMapping(value="/listVehicle", method = RequestMethod.GET)
	public ModelAndView listVehicle() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("vehicles", prepareListofBean(vehicleService.listVehicleService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("vehicleListForm", model);
	}
	
	@RequestMapping(value = "/vadd", method = RequestMethod.GET)
	public ModelAndView addVehicle(@ModelAttribute("command")  VehicleBean vehicleBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("vehicles",  prepareListofBean(vehicleService.listVehicleService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addVehicleForm", model);
	}
	
	
	private Vehicle prepareModel(VehicleBean vehicleBean){
		Vehicle vehicle = new Vehicle();
		vehicle.setCvId(vehicleBean.getvId());
		vehicle.setCaddressOfOrganization(vehicleBean.getAddressOfOrganization());
		vehicle.setCdesignation(vehicleBean.getDesignation());
		vehicle.setCoccupation(vehicleBean.getOccupation());
		vehicle.setCvehicleModel(vehicleBean.getVehicleModel());
		vehicle.setCvehicleType(vehicleBean.getVehicleType());
		vehicle.setCnameOfOrganization(vehicleBean.getNameOfOrganization());
		vehicle.setId(vehicleBean.getId());
		return vehicle;
		
	}
	
	private List<VehicleBean> prepareListofBean(List<Vehicle> vehicles){
		List<VehicleBean> beans = null;
		if(vehicles != null && !vehicles.isEmpty()){
			beans = new ArrayList<VehicleBean>();
			VehicleBean bean = null;
			for(Vehicle vehicle : vehicles){
				bean = new VehicleBean();
				
				bean.setAddressOfOrganization(vehicle.getCaddressOfOrganization());
				bean.setDesignation(vehicle.getCdesignation());
				bean.setNameOfOrganization(vehicle.getCnameOfOrganization());
				bean.setOccupation(vehicle.getCoccupation());
				bean.setVehicleModel(vehicle.getCvehicleModel());
				bean.setVehicleType(vehicle.getCvehicleType());
				bean.setvId(vehicle.getCvId());
				bean.setId(vehicle.getId());
				
				beans.add(bean);
			}
		}
		return beans;
	}
	
	

}
