package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.PropertyBean;
import com.loan.model.Property;
import com.loan.service.PropertyService;

@Controller
public class PropertyController {
	
	@Autowired
	private PropertyService propertyService;

	public void setPropertyService(PropertyService propertyService) {
		this.propertyService = propertyService;
	}
	
	@RequestMapping(value = "/psave", method = RequestMethod.POST)
	public ModelAndView saveProperty(@ModelAttribute("command") PropertyBean propertyBean ,
			BindingResult result,HttpServletRequest request) {
		
		Integer v = (Integer)request.getSession().getAttribute("id");
		propertyBean.setId(v);
		
		
		Property property = prepareModel(propertyBean);
		try
		{
			propertyService.addPropertyService(property);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/hadd.html");
	}
	

	
	@RequestMapping(value="/listProperty", method = RequestMethod.GET)
	public ModelAndView listProperty() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("properties", prepareListofBean(propertyService.listPropertyService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("propertyListForm", model);
	}
	
	@RequestMapping(value = "/padd", method = RequestMethod.GET)
	public ModelAndView addProperty(@ModelAttribute("command")  PropertyBean propertyBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("properties",  prepareListofBean(propertyService.listPropertyService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addPropertyForm", model);
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("redirect:/index.jsp");
	}
	
	
	private Property prepareModel(PropertyBean propertyBean){
		Property property = new Property();
		property.setCaddress(propertyBean.getAddress());
		property.setCbuilderName(propertyBean.getBuilderName());
		property.setCbuiltupArea(propertyBean.getBuiltupArea());
		property.setId(propertyBean.getId());
		property.setClandArea(propertyBean.getLandArea());
		property.setCnpropertyId(propertyBean.getNpropertyId());
		property.setCregOwner(propertyBean.getRegOwner());
		property.setCtypeProperty(propertyBean.getTypeProperty());
		property.setCusesProperty(propertyBean.getUsesProperty());
	
		return property;
	}
	
	private List<PropertyBean> prepareListofBean(List<Property> properties){
		List<PropertyBean> beans = null;
		if(properties != null && !properties.isEmpty()){
			beans = new ArrayList<PropertyBean>();
			PropertyBean bean = null;
			for(Property property : properties){
				bean = new PropertyBean();
				
				bean.setAddress(property.getCaddress());
				bean.setBuilderName(property.getCbuilderName());
				bean.setBuiltupArea(property.getCbuiltupArea());
				bean.setId(property.getId());
				bean.setLandArea(property.getClandArea());
				bean.setNpropertyId(property.getCnpropertyId());
				bean.setRegOwner(property.getCregOwner());
				bean.setTypeProperty(property.getCtypeProperty());
				bean.setUsesProperty(property.getCusesProperty());
			
				
				beans.add(bean);
			}
		}
		return beans;
	}

}
