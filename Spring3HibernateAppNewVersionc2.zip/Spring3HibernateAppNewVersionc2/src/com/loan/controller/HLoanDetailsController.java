package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.HLoanDetailsBean;
import com.loan.model.HLoanDetails;
import com.loan.service.HLoanDetailsService;

@Controller
public class HLoanDetailsController {
	
	@Autowired
	private HLoanDetailsService hLoanDetailsService;

	public void sethLoanDetailsService(HLoanDetailsService hLoanDetailsService) {
		this.hLoanDetailsService = hLoanDetailsService;
	}
	
	
	@RequestMapping(value = "/hsave", method = RequestMethod.POST)
	public ModelAndView saveHLoanDetails(@ModelAttribute("command") HLoanDetailsBean hLoanDetailsBean, 
			BindingResult result,HttpServletRequest request) {
		
		Integer v = (Integer)request.getSession().getAttribute("id");
		hLoanDetailsBean.setId(v);
		
		HLoanDetails hLoanDetails = prepareModel(hLoanDetailsBean);
		try
		{
			hLoanDetailsService.addHLoanDetailsService(hLoanDetails);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/indexdocument.html");
	}
	
	
	
	@RequestMapping(value="/listDetails", method = RequestMethod.GET)
	public ModelAndView listHLoanDetails() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("hLoanDetails1", prepareListofBean(hLoanDetailsService.listHLoanDetailsService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("ListHLoanDetailsForm", model);
	}
	
	@RequestMapping(value = "/hadd", method = RequestMethod.GET)
	public ModelAndView addHLoanDetails(@ModelAttribute("command")  HLoanDetailsBean hLoanDetailsBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("hLoanDetails1",  prepareListofBean(hLoanDetailsService.listHLoanDetailsService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addHLoanDetailsForm", model);
	}
	

	private HLoanDetails prepareModel(HLoanDetailsBean hLoanDetailsBean){
		HLoanDetails hloanDetails = new HLoanDetails();
		
		hloanDetails.setChloanId(hLoanDetailsBean.getHloanId());
		hloanDetails.setCcostOfProperty(hLoanDetailsBean.getCostOfProperty());
		hloanDetails.setCtenure(hLoanDetailsBean.getTenure());
		hloanDetails.setChinterest(11);
		hloanDetails.setChloanAmount(hLoanDetailsBean.getHloanAmount());
		hloanDetails.setChrepayment(hLoanDetailsBean.getHrepayment());
		hloanDetails.setId(hLoanDetailsBean.getId());
		hloanDetails.setStatus(hLoanDetailsBean.getStatus());
		hloanDetails.setTypeLoan("Home Loan");
		
		
		return hloanDetails;
	}
	
	
	private List<HLoanDetailsBean> prepareListofBean(List<HLoanDetails> hloanDetails1){
		List<HLoanDetailsBean> beans = null;
		if(hloanDetails1 != null && !hloanDetails1.isEmpty()){
			beans = new ArrayList<HLoanDetailsBean>();
			HLoanDetailsBean bean = null;
			for(HLoanDetails hloanDetail : hloanDetails1){
				bean = new HLoanDetailsBean();
				bean.setCostOfProperty(hloanDetail.getCcostOfProperty());
				bean.setId(hloanDetail.getId());
				bean.setHinterest(hloanDetail.getChinterest());
				bean.setHloanAmount(hloanDetail.getChloanAmount());
				bean.setHloanId(hloanDetail.getChloanId());
				bean.setHrepayment(hloanDetail.getChrepayment());
				bean.setTenure(hloanDetail.getCtenure());
				bean.setTypeLoan(hloanDetail.getTypeLoan());
				bean.setStatus(hloanDetail.getStatus());
				beans.add(bean);
			}
			
		}
		return beans;
	
	}
	
	
}
	

