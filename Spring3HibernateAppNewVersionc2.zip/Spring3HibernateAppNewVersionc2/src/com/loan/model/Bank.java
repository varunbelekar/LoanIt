package com.loan.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank101")
public class Bank {
	@Id
	@Column(name="cbankId")
	private Long cbankId;
	
	@Column(name="cnameOfBank")
	private String cnameOfBank;
	
	@Column(name="caccountNo")
	private Long caccountNo;
	
	@Column(name="cIfscCode")
	private String cIfscCode;
	
	@Column(name="id")
	private Integer id;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getCbankId() {
		return cbankId;
	}

	public void setCbankId(Long cbankId) {
		this.cbankId = cbankId;
	}

	public String getCnameOfBank() {
		return cnameOfBank;
	}

	public void setCnameOfBank(String cnameOfBank) {
		this.cnameOfBank = cnameOfBank;
	}

	public Long getCaccountNo() {
		return caccountNo;
	}

	public void setCaccountNo(Long caccountNo) {
		this.caccountNo = caccountNo;
	}

	public String getcIfscCode() {
		return cIfscCode;
	}

	public void setcIfscCode(String cIfscCode) {
		this.cIfscCode = cIfscCode;
	}

	public Bank() {
		
		// TODO Auto-generated constructor stub
	}

	public Bank(Long cbankId, String cnameOfBank, Long caccountNo, String cIfscCode) {
		
		this.cbankId = cbankId;
		this.cnameOfBank = cnameOfBank;
		this.caccountNo = caccountNo;
		this.cIfscCode = cIfscCode;
	}

	
	
	
	
}
