package com.loan.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employer")
public class Employer implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="employerId")
	private Integer cemployerId;
	
	@Column(name="employerName")
	private String cemployerName;
	
	@Column(name="employerAddress")
	private String cemployerAddress;
	
	@Column(name="employerTelephone")
	private Long cemployerTelephone;
	
	@Column(name="id")
	private Integer id;
	
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Employer() {
	
	}

	public Employer(Integer cemployerId, String cemployerName, String cemployerAddress, Long cemployerTelephone) {
		this.cemployerId = cemployerId;
		this.cemployerName = cemployerName;
		this.cemployerAddress = cemployerAddress;
		this.cemployerTelephone = cemployerTelephone;
	}

	public Integer getCemployerId() {
		return cemployerId;
	}

	public void setCemployerId(Integer cemployerId) {
		this.cemployerId = cemployerId;
	}

	public String getCemployerName() {
		return cemployerName;
	}

	public void setCemployerName(String cemployerName) {
		this.cemployerName = cemployerName;
	}

	public String getCemployerAddress() {
		return cemployerAddress;
	}

	public void setCemployerAddress(String cemployerAddress) {
		this.cemployerAddress = cemployerAddress;
	}

	public Long getCemployerTelephone() {
		return cemployerTelephone;
	}

	public void setCemployerTelephone(Long cemployerTelephone) {
		this.cemployerTelephone = cemployerTelephone;
	}
	
	
	
}
