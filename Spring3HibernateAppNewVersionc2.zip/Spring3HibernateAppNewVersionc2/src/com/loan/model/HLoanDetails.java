package com.loan.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="loandetails")
public class HLoanDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="hloanId")
	private Integer chloanId;
	
	@Column(name="hloanAmount")
	private Integer chloanAmount;
	
	@Column(name="costOfProperty")
	private Integer ccostOfProperty;
	
	@Column(name="tenure")
	private Integer ctenure;
	
	@Column(name="hrepayment")
	private String chrepayment;
	
	@Column(name="hinterest")
	private Integer chinterest;
	
	@Column(name="id")
	private Integer id;
	
	@Column(name="typeLoan")
	private String typeLoan;
	

	@Column(name="status")
	private String status;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getChloanId() {
		return chloanId;
	}

	public void setChloanId(Integer chloanId) {
		this.chloanId = chloanId;
	}

	public Integer getChloanAmount() {
		return chloanAmount;
	}

	public void setChloanAmount(Integer chloanAmount) {
		this.chloanAmount = chloanAmount;
	}

	public Integer getCcostOfProperty() {
		return ccostOfProperty;
	}

	public void setCcostOfProperty(Integer ccostOfProperty) {
		this.ccostOfProperty = ccostOfProperty;
	}
	
	


	public Integer getCtenure() {
		return ctenure;
	}




	public void setCtenure(Integer ctenure) {
		this.ctenure = ctenure;
	}




	public String getChrepayment() {
		return chrepayment;
	}

	public void setChrepayment(String chrepayment) {
		this.chrepayment = chrepayment;
	}

	public Integer getChinterest() {
		return chinterest;
	}

	public void setChinterest(Integer chinterest) {
		this.chinterest = chinterest;
	}


	public String getTypeLoan() {
		return typeLoan;
	}

	public void setTypeLoan(String typeLoan) {
		this.typeLoan = typeLoan;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	

}
