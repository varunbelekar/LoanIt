package com.loan.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehicle")
public class Vehicle implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="vId")
	private Integer cvId;
	
	@Column(name="occupation")
	private String coccupation;
	
	@Column(name="designation")
	private String cdesignation;
	
	@Column(name="nameOfOrganization")
	private String cnameOfOrganization;
	
	@Column(name="addressOfOrganization")
	private String caddressOfOrganization;
	
	@Column(name="vehicleType")
	private String cvehicleType;
	
	@Column(name="vehicleModel")
	private String cvehicleModel;
	
	@Column(name="id")
	private Integer id;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCvId() {
		return cvId;
	}

	public void setCvId(Integer cvId) {
		this.cvId = cvId;
	}

	public String getCoccupation() {
		return coccupation;
	}

	public void setCoccupation(String coccupation) {
		this.coccupation = coccupation;
	}

	public String getCdesignation() {
		return cdesignation;
	}

	public void setCdesignation(String cdesignation) {
		this.cdesignation = cdesignation;
	}

	public String getCnameOfOrganization() {
		return cnameOfOrganization;
	}

	public void setCnameOfOrganization(String cnameOfOrganization) {
		this.cnameOfOrganization = cnameOfOrganization;
	}

	public String getCaddressOfOrganization() {
		return caddressOfOrganization;
	}

	public void setCaddressOfOrganization(String caddressOfOrganization) {
		this.caddressOfOrganization = caddressOfOrganization;
	}

	public String getCvehicleType() {
		return cvehicleType;
	}

	public void setCvehicleType(String cvehicleType) {
		this.cvehicleType = cvehicleType;
	}

	public String getCvehicleModel() {
		return cvehicleModel;
	}

	public void setCvehicleModel(String cvehicleModel) {
		this.cvehicleModel = cvehicleModel;
	}
	
	
	

}
