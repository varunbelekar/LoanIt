package com.loan.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="property")
public class Property implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="npropertyId")
	private Integer cnpropertyId;
	
	@Column(name="builderName")
	private String cbuilderName;
	
	@Column(name="regOwner")
	private String cregOwner;
	
	@Column(name="address")
	private String caddress;
	
	@Column(name="landArea")
	private float clandArea;
	
	@Column(name="builtupArea")
	private float cbuiltupArea;
	
	@Column(name="typeProperty")
	private String ctypeProperty;
	
	@Column(name="usesProperty")
	private String cusesProperty;
	
	@Column(name="id")
	private Integer id;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCnpropertyId() {
		return cnpropertyId;
	}

	public void setCnpropertyId(Integer cnpropertyId) {
		this.cnpropertyId = cnpropertyId;
	}

	public String getCbuilderName() {
		return cbuilderName;
	}

	public void setCbuilderName(String cbuilderName) {
		this.cbuilderName = cbuilderName;
	}

	public String getCregOwner() {
		return cregOwner;
	}

	public void setCregOwner(String cregOwner) {
		this.cregOwner = cregOwner;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public float getClandArea() {
		return clandArea;
	}

	public void setClandArea(float clandArea) {
		this.clandArea = clandArea;
	}

	public float getCbuiltupArea() {
		return cbuiltupArea;
	}

	public void setCbuiltupArea(float cbuiltupArea) {
		this.cbuiltupArea = cbuiltupArea;
	}

	public String getCtypeProperty() {
		return ctypeProperty;
	}

	public void setCtypeProperty(String ctypeProperty) {
		this.ctypeProperty = ctypeProperty;
	}

	public String getCusesProperty() {
		return cusesProperty;
	}

	public void setCusesProperty(String cusesProperty) {
		this.cusesProperty = cusesProperty;
	}
	
	
	

}
