package com.loan.model;


	

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="personal1")
	public class Person implements Serializable{
		
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name="id")
		private Integer id;
		
		@Column(name="name")
		private String name;
		
	
		@Column(name="gender")
		private String gender;
		
		@Column(name="dob")
		
		private String dob;
		
		@Column(name="email")
		private String email;
		
		@Column(name="adhar")
		private String adhar;
		
		@Column(name="nationality")
		private String nationality;
		
		@Column(name="category")
		private String category;
		
		@Column(name="address")
		private String address;
		
		@Column(name="pincode")
		private String pincode;
		
		@Column(name="mobilenumber")
		private String mobilenumber;
		
		@Column(name="pan")
		private String pan;	
		
		@Column(name="voterid")
		private String voterid;
		
		@Column(name="cid")
		private Integer cid;
		
		
		

		public Integer getCid() {
			return cid;
		}

		public void setCid(Integer cid) {
			this.cid = cid;
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		

		

		public String getDob() {
			return dob;
		}

		public void setDob(String dob) {
			this.dob = dob;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getAdhar() {
			return adhar;
		}

		public void setAdhar(String adhar) {
			this.adhar = adhar;
		}

		public String getNationality() {
			return nationality;
		}

		public void setNationality(String nationality) {
			this.nationality = nationality;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getPincode() {
			return pincode;
		}

		public void setPincode(String pincode) {
			this.pincode = pincode;
		}

		

		

		public String getMobilenumber() {
			return mobilenumber;
		}

		public void setMobilenumber(String mobilenumber) {
			this.mobilenumber = mobilenumber;
		}

		public String getPan() {
			return pan;
		}

		public void setPan(String pan) {
			this.pan = pan;
		}

		public String getVoterid() {
			return voterid;
		}

		public void setVoterid(String voterid) {
			this.voterid = voterid;
		}
		
		
		
		
		
	}


