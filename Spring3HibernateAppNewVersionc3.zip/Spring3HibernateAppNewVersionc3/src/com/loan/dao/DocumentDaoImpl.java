package com.loan.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.loan.model.Document;
import com.loan.model.Person;

public class DocumentDaoImpl implements DocumentDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void save(Document document) {
		Session session = sessionFactory.getCurrentSession();
		session.save(document);
	}

	@Override
	public List<Document> list() {
		Session session = sessionFactory.getCurrentSession();
		List<Document> documents = null;
		try {
			documents = (List<Document>)session.createQuery("from Document").list();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return documents;
		
	}

	@Override
	public List get(Integer id) {
		
		Session session = sessionFactory.getCurrentSession();
		String query = "from Document where id=?";
		Query qry = session.createQuery(query);
		qry.setParameter(0, id);
		List list = qry.list();
		return list;
	}

	@Override
	public void remove(Integer id) {
		Session session = sessionFactory.getCurrentSession();

		Document document = (Document) session.get(Document.class, id);

		session.delete(document);
	}	
	
	
	
	public int updateStatus(Integer id, String status) {
		Session session= sessionFactory.openSession();
		String qry = "UPDATE HLoanDetails set status=? where hloanId=?";
		Query query = session.createQuery(qry);
		query.setParameter(0, status);
		query.setParameter(1, id);
		int result = query.executeUpdate();
		System.out.println(result);
		return result;
	}
	
	
	
	
	public List getPersonal(Integer id) {
		
		Session session= sessionFactory.getCurrentSession();
		
		Query query = session.createQuery("select name,id from Person where cid=? ");
		query.setParameter(0, id);
	
		List list = query.list();
		
		return list;
		
	}
	
	
	public List getStatus(Integer id) {
		
		Session session= sessionFactory.getCurrentSession();
		
		Query query = session.createQuery("from HLoanDetails where id=? ");
		query.setParameter(0, id);
	
		List list = query.list();
		
		return list;
		
	}

	@Override
	public List getLoan(Integer id) {
		Session session= sessionFactory.openSession();
		String qry = "SELECT chloanId FROM HLoanDetails WHERE id=?";
		Query query = session.createQuery(qry);
		query.setParameter(0, id);
		List list = query.list();
		return list;
	}
	
	@Override
	public List getLoans(Integer id) {
		Session session= sessionFactory.openSession();
		String qry = "FROM HLoanDetails WHERE id=?";
		Query query = session.createQuery(qry);
		query.setParameter(0, id);
		List list = query.list();
		/*System.out.println(list.toString());*/
		return list;
	}

	@Override
	public List<Person> listPersonal() {
		Session session = sessionFactory.getCurrentSession();
		List<Person> persons = null;
		try {
			persons = (List<Person>)session.createQuery("from Person").list();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return persons;
	}
	
	
	
}
