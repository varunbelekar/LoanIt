package com.loan.dao;

import java.util.List;

import com.loan.model.Property;


public interface PropertyDAO {
	
	public void addProperty(Property property) throws Exception;
	
	public List<Property> listProperty() throws Exception;

}
