package com.loan.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.loan.model.Person;


public class PersonalDaoImpl implements PersonalDao {

private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	@Override
	public void addPerson(Person person) throws Exception {
		sessionFactory.getCurrentSession().save(person);
	}
	
	@Override
	public List<Person> listPersonal() {
		Session session = sessionFactory.getCurrentSession();
		List<Person> persons = null;
		try {
			persons = (List<Person>)session.createQuery("from Person").list();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return persons;
	}



	@Override
	public List<Person> getPerson(Integer cid) {
		Session session = sessionFactory.getCurrentSession();
		/*Person person = new Person();*/
		List<Person> persons = null;
		try {
			Query query = session.createQuery("from Person where cid=?");
			query.setParameter(0, cid);
			persons = query.list();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return persons;
		
	}

}
