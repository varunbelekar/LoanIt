package com.loan.dao;

import java.util.List;

import com.loan.model.Employment;

public interface EmploymentDAO {
	
	public void addEmployment(Employment employment) throws Exception;
	
	public List<Employment> listEmployment() throws Exception;

}
