package com.loan.dao;

import com.loan.model.Users;

public interface UserDao {
	
	public boolean checkLogin(String userName, String userPassword) throws Exception;
	
	public Users getLogin(String userName, String userPassword) throws Exception;
}
