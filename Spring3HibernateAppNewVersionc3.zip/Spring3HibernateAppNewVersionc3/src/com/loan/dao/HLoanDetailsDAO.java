package com.loan.dao;

import java.util.List;

import com.loan.model.HLoanDetails;

public interface HLoanDetailsDAO {
	
	public void addHLoanDetails(HLoanDetails hLoanDetails ) throws Exception;
	
	public List<HLoanDetails> listHLoanDetails() throws Exception;


}
