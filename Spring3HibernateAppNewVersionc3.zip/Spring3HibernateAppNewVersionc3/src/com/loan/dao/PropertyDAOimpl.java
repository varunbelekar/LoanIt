package com.loan.dao;

import java.util.List;

import org.hibernate.SessionFactory;


import com.loan.model.Property;

public class PropertyDAOimpl implements PropertyDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addProperty(Property property) throws Exception {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(property);

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Property> listProperty() throws Exception {
		// TODO Auto-generated method stub
		return (List<Property>) sessionFactory.getCurrentSession().createCriteria(Property.class).list();
	}

}
