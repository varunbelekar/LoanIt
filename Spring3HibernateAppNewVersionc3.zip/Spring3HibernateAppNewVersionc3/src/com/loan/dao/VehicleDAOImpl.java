package com.loan.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.loan.model.Vehicle;

public class VehicleDAOImpl implements VehicleDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addVehicle(Vehicle vehicle) throws Exception {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(vehicle);

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Vehicle> listVehicle() throws Exception {
		// TODO Auto-generated method stub
		return (List<Vehicle>) sessionFactory.getCurrentSession().createCriteria(Vehicle.class).list();
	}

}
