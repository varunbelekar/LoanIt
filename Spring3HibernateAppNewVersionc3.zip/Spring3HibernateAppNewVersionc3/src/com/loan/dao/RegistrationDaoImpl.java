package com.loan.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.loan.model.Users;

public class RegistrationDaoImpl implements RegistrationDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addUsers(Users user) throws Exception {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		
	}
	
	@Override
	public boolean checkques(String questions, String answer) throws Exception {
		Session session = sessionFactory.openSession();
		
		boolean userFound=false;
		String SQL_QUERY =" from Users as o where o.questions=? and o.answer=?";
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter(0,questions);
		query.setParameter(1,answer);
		List list = query.list();

		if ((list != null) && (list.size() > 0)) {
			userFound= true;
		}

		
		return userFound;            
	}

	@Override
	public List<Users> findUser(String email) throws Exception {
		/*return (Users) sessionFactory.getCurrentSession().get(Users.class, email);*/
		Session session = sessionFactory.openSession();
		String SQL_QUERY =" from Users as o where o.email=?";
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter(0,email);
		
		List list = query.list();
		
		return list;
	
	}
	
	

	@Override
	public String signOut(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "index";
	}

	@Override
	public int changePassword(String email, String password) throws Exception {

		Session session = sessionFactory.openSession();
		String query = "UPDATE Users set password = ? where email=? ";
		Query qry = session.createQuery(query);
		qry.setParameter(0, password);
		qry.setParameter(1, email);
		int result = qry.executeUpdate();
		System.out.println(result);
		return result;
	}
}
