package com.loan.dao;

import java.util.List;

import com.loan.model.Employer;

public interface EmployerDAO {
	
	public void addEmployer(Employer employer) throws Exception;
	
	public List<Employer> listEmployer() throws Exception;


}
