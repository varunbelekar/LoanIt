package com.loan.dao;

import java.util.List;

import com.loan.model.Bank;

public interface BankDAO {
	public void addBank(Bank bank) throws Exception;
	
	public List<Bank> listBank() throws Exception;
}
