package com.loan.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.loan.model.Bank;
import com.loan.model.Employment;

public class BankDAOImpl implements BankDAO {

	
	private SessionFactory sessionFactory;

	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addBank(Bank bank) throws Exception {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(bank);

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Bank> listBank() throws Exception {
		// TODO Auto-generated method stub
		return (List<Bank>) sessionFactory.getCurrentSession().createCriteria(Bank.class).list();
	}

}
