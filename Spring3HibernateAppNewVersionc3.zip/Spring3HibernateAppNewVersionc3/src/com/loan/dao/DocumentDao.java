package com.loan.dao;

import java.util.List;

import com.loan.model.Document;
import com.loan.model.Person;

public interface DocumentDao {
public void save(Document document);
	
	
	public List<Document> list();
	
	public List get(Integer id);

	public void remove(Integer id);
	
	public int updateStatus(Integer id, String status);
	
	public List getPersonal(Integer id);
	
	public List<Person> listPersonal();
	
	public List getStatus(Integer id);
	
	public List getLoan(Integer id);
	
	public List getLoans(Integer id);

}
