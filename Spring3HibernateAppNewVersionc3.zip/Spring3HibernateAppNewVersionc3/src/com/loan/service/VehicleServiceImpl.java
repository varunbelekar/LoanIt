package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.VehicleDAO;
import com.loan.model.Vehicle;

@Service("vehicleService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class VehicleServiceImpl implements VehicleService{
	
	@Autowired
	private VehicleDAO vehicleDao;
	
	

	public void setVehicleDao(VehicleDAO vehicleDao) {
		this.vehicleDao = vehicleDao;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addVehicleService(Vehicle vehicle) throws Exception {
		// TODO Auto-generated method stub
		vehicleDao.addVehicle(vehicle);
		
	}

	@Override
	public List<Vehicle> listVehicleService() throws Exception {
		// TODO Auto-generated method stub
		return vehicleDao.listVehicle();
	}

}
