package com.loan.service;

import java.util.List;

import com.loan.model.Employment;

public interface EmploymentService {
	
	public void addEmploymentService(Employment employment) throws Exception;
	
	public List<Employment> listEmploymentService() throws Exception;


}
