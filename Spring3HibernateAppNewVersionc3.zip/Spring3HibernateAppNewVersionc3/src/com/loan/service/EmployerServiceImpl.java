package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.EmployerDAO;
import com.loan.model.Employer;

@Service("employerService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)



public class EmployerServiceImpl implements EmployerService {
	
	@Autowired
	private EmployerDAO employerDAO;

	public void setEmployerDAO(EmployerDAO employerDAO) {
		this.employerDAO = employerDAO;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addEmployerService(Employer employer) throws Exception {
		// TODO Auto-generated method stub
		employerDAO.addEmployer(employer);
		System.out.println("hii service");


	}

	@Override
	public List<Employer> listEmployerService() throws Exception {
		// TODO Auto-generated method stub
		return employerDAO.listEmployer();
	}


}

