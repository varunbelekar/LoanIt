package com.loan.service;

import java.util.List;

import com.loan.model.Bank;
import com.loan.model.Employment;

public interface BankService {
	
	public void addBankService(Bank bank) throws Exception;
	
	public List<Bank> listBankService() throws Exception;
}
