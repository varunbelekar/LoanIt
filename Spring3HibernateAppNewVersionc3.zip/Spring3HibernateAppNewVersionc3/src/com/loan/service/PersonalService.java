package com.loan.service;



import java.util.List;

import com.loan.model.Person;

public interface PersonalService {

	public void addPerson(Person person) throws Exception;
	
	public List<Person> getPerson(Integer cid);
	
	public List<Person> listPersonal();
}
