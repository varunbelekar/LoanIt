package com.loan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.DocumentDao;
import com.loan.model.Document;
import com.loan.model.Person;

@Service("documentService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DocumentServiceImpl implements DocumentService {

	@Autowired
	private DocumentDao documentDao;
	


	public void setDocumentDao(DocumentDao documentDao) {
		this.documentDao = documentDao;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void save(Document document) {
		documentDao.save(document);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public List<Document> list() {
		return documentDao.list();
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public List get(Integer id) {
		return documentDao.get(id);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void remove(Integer id) {
		documentDao.remove(id);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public int updateStatus(Integer id, String status) {
		return documentDao.updateStatus(id,status);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public List getPersonal(Integer id) {
		return documentDao.getPersonal(id);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public List getStatus(Integer id) {
		return documentDao.getStatus(id);
	}

	@Override
	public List getLoan(Integer id) {
		return documentDao.getLoan(id);
	}

	@Override
	public List<Person> listPersonal() {
		return documentDao.listPersonal();
	}

	@Override
	public List getLoans(Integer id) {
		return documentDao.getLoans(id);
	}
	
}	
