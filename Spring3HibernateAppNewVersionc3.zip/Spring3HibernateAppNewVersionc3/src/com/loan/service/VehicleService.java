package com.loan.service;

import java.util.List;

import com.loan.model.Vehicle;

public interface VehicleService {
	
	public void addVehicleService(Vehicle vehicle) throws Exception;
	
	public List<Vehicle> listVehicleService() throws Exception;

}
