package com.loan.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.loan.model.Users;

public interface RegistrationService {
	public void addUsers(Users user) throws Exception;
	
	public List<Users> findUser(String email) throws Exception;
	
	public boolean checkques(String questions, String answer) throws Exception;
	
	public int changePassword(String email, String password) throws Exception;
	
	public String signOut(HttpServletRequest request);
}
