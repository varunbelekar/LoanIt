package com.loan.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.RegistrationDao;
import com.loan.model.Users;



@Service("registrationService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	private RegistrationDao registrationDao;
	
	public void setRegistrationDao(RegistrationDao registrationDao) {
		this.registrationDao = registrationDao;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUsers(Users user) throws Exception {
		try
		{
			registrationDao.addUsers(user);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public boolean checkques(String questions, String answer) throws Exception {
		boolean isCorrect = false;
		try {
			isCorrect = registrationDao.checkques(questions, answer);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return isCorrect;
	}

	@Override
	public List<Users> findUser(String email) throws Exception {

		return registrationDao.findUser(email);
	}

	@Override
	public String signOut(HttpServletRequest request) {
		try {
			registrationDao.signOut(request);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int changePassword(String email, String password) throws Exception {

		System.out.println(password + " " + email);
		return registrationDao.changePassword(email, password);
	}

}
