package com.loan.service;

import com.loan.model.Users;

public interface UserService {
	public boolean checkLogin(String userName, String userPassword) throws Exception;
	
	public Users getLogin(String userName, String userPassword) throws Exception;
}
