package com.loan.service;

import java.util.List;

import com.loan.model.Employer;

public interface EmployerService {
	
	public void addEmployerService(Employer employer) throws Exception;
	
	public List<Employer> listEmployerService() throws Exception;

}
