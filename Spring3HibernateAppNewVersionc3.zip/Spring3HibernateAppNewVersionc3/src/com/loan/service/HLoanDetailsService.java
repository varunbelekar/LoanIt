package com.loan.service;

import java.util.List;

import com.loan.model.HLoanDetails;

public interface HLoanDetailsService {
	
	public void addHLoanDetailsService(HLoanDetails hLoanDetails) throws Exception;
	
	public List<HLoanDetails> listHLoanDetailsService() throws Exception;


}
