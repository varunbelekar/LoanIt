package com.loan.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.loan.bean.Registration;

public class RegistrationValidation {
	public boolean supports(Class<?> klass) {
		return Registration.class.isAssignableFrom(klass);
	}

	public void validate(Object target, Errors errors) {
		Registration registration = (Registration) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name",
				"NotEmpty.registration.name",
				"User Name must not be Empty.");
		String userName = registration.getName();
		if ((userName.length()) > 50) {
			errors.rejectValue("name",
					"lengthOfUser.registration.name",
					"User Name must not more than 50 characters.");
		}
		if (!(registration.getPassword()).equals(registration
				.getCpassword())) {
			errors.rejectValue("password",
					"matchingPassword.registration.password",
					"Password and Confirm Password Not match.");
		}
	}
}