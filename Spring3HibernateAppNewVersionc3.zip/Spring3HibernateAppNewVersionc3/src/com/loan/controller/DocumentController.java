package com.loan.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.loan.model.Document;
import com.loan.model.HLoanDetails;
import com.loan.model.Person;
import com.loan.model.Users;
import com.loan.service.DocumentService;
import com.loan.service.PersonalService;

@Controller
public class DocumentController {
	
	@Autowired
	private DocumentService documentService;
	
	private PersonalService personalService;

	public void setDocumentService(DocumentService documentService) {
		this.documentService = documentService;
	}

	
	public void setPersonalService(PersonalService personalService) {
		this.personalService = personalService;
	}


	/*@RequestMapping("/imageshow")
	public void showimage(@RequestParam("documentId") Integer documentId, HttpServletResponse response,HttpServletRequest request) 
	          throws ServletException, IOException,SQLException{
		Document doc = documentService.get(documentId);
		Blob blob = doc.getContent();

		int blobLength = (int) blob.length();  
		byte[] blobAsBytes = blob.getBytes(1, blobLength);

		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	    response.getOutputStream().write(blobAsBytes);


	    response.getOutputStream().close();
		//blob.free();
	}*/
	
	@RequestMapping(value = "/final", method = RequestMethod.GET)
	public ModelAndView finalv()
	{
	
	System.out.println("in final");
		return new ModelAndView("finalpage");
		
	}
	
	@RequestMapping("/indexdocument")
	public String index(Map<String, Object> map) {
		try {
			map.put("document", new Document());
			map.put("documentList", documentService.list());
		}catch(Exception e) {
			e.printStackTrace();
		}

		return "documents";
	}
	
	@RequestMapping("/applicationlist")
	public String applicationList(Map<String,Object> map) {
		map.put("application", new Person());
		map.put("applicationList", personalService.listPersonal());
		return "applicationlist";
		
	}
	
	@RequestMapping("/documentlist")
	public String list(Map<String, Object> map){
		try{
			map.put("document", new Document());
			map.put("documentList", documentService.list());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return "documentlist";
	}

	@RequestMapping(value = "/savedocument", method = RequestMethod.POST)
	public String save(
			@ModelAttribute("document") Document document,
			@RequestParam("file") MultipartFile file,HttpServletRequest request) {
		
		System.out.println("Name:" + document.getName());
		System.out.println("File:" + file.getName());
		System.out.println("ContentType:" + file.getContentType());
		Integer v=0;
		try {
			
			Blob blob = Hibernate.createBlob(file.getInputStream());
			//byte[] blob = file.getBytes();
			
			document.setFilename(file.getOriginalFilename());
			document.setContent(blob);
			document.setContentType(file.getContentType());
			
			 v = (Integer)request.getSession().getAttribute("id");
			System.out.println(v);
			document.setId(v);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			documentService.save(document);
		} catch(Exception e) {
			e.printStackTrace();
		}
		Users user = (Users) request.getSession().getAttribute("user");
		Long user_id = user.getId();
		return "redirect:/userDash.html?id="+user_id;
	}


	@RequestMapping("/download")
	public String download(@RequestParam("id")
			Integer documentId, HttpServletResponse response) {
		
		List list = documentService.get(documentId);
		if(!list.isEmpty()) {
			Document doc = (Document) list.get(0);
			try {
				response.setHeader("Content-Disposition", "inline;filename=\"" +doc.getFilename()+ "\"");
				OutputStream out = response.getOutputStream();
				response.setContentType(doc.getContentType());
				
				IOUtils.copy(doc.getContent().getBinaryStream(), out);
				
				out.flush();
				out.close();
			
			} catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return null;
	}

	@RequestMapping("/remove/{documentId}")
	public String remove(@PathVariable("documentId")
			Integer documentId) {
		
		documentService.remove(documentId);
		
		return "redirect:/indexdocument.html";
	}
	
	
	@RequestMapping(value="/updateStatus")
	public String decline(@RequestParam("id")Integer id,@RequestParam("status")String status,Map map) {
		List loans = documentService.getLoan(id);
		int loan_id = (int) loans.get(0);
		System.out.println(loan_id);
		System.out.println(id);
		System.out.println(status);
		int rs = documentService.updateStatus(loan_id, status);
		if(rs>0) {
			map.put("application", new Person());
			map.put("applicationList", personalService.listPersonal());
			return "applicationlist";
		}

		return "currentcust";
	}
	
	@RequestMapping(value="/currentcust")
	public String current(@RequestParam("id") Integer id, HttpServletResponse response,HttpServletRequest request,Map<String, Object> model){
		model.put("current", documentService.get(id));
		
		return "currentcust";
	}
	
	@RequestMapping("/userDash")
	public String userDash(@RequestParam("id") Integer id, Map model) {
		List<Person> persons = personalService.getPerson(id);
		//System.out.println(persons);
		List loans = null;
		//List<List> loan = null;
		Integer app_id = 0;
		if(!persons.isEmpty()) {
			
				app_id = persons.get(0).getId();
				//System.out.println(loans);
			
		}
		
		model.put("loan", new HLoanDetails());
		model.put("loanDetails", documentService.getLoans(app_id));
		
		return "Hello";
	}
	
	@RequestMapping("/getStatus")
	public String getStatus(@RequestParam("id") Integer id,Map model) {
		model.put("myLoan", documentService.getStatus(id));
		return "Hello";
	}
	

}

