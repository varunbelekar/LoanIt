package com.loan.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.PersonBean;
import com.loan.model.Person;
import com.loan.model.Users;
import com.loan.service.PersonalService;

@Controller
public class VpersonalController {
	@Autowired
	private PersonalService personalService;

	public void setPersonalService(PersonalService personalService) {
		this.personalService = personalService;
	}
	
	@RequestMapping(value = "/personal2",method=RequestMethod.GET)
	public String showPersonal(Map model){
		Person person = new Person();
		model.put("person", person);
		return "vpersonal";
	}
	
	@RequestMapping(value = "/vpersonal",method=RequestMethod.POST)
	public ModelAndView processPersonal(@ModelAttribute("command")PersonBean person, BindingResult result,HttpServletRequest request){
		
		Person persons = prepareModel(person);
		Users user = (Users) request.getSession().getAttribute("user");
		Long cid = user.getId();
		persons.setCid(cid.intValue());
		Integer v = person.getId();
		request.getSession().setAttribute("id",v);
		try {
			personalService.addPerson(persons);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("redirect:/vadd.html");
	}

	private Person prepareModel(PersonBean person) {
		Person persons = new Person();
		persons.setId(person.getId());
		persons.setName(person.getName());
		persons.setGender(person.getGender());
		persons.setDob(person.getDob());
		persons.setEmail(person.getEmail());
		persons.setAdhar(person.getAdhar());
		persons.setNationality(person.getNationality());
		persons.setCategory(person.getCategory());
		persons.setAddress(person.getAddress());
		persons.setPincode(person.getPincode());
		persons.setMobilenumber(person.getMobilenumber());
		persons.setPan(person.getPan());
		persons.setVoterid(person.getVoterid());
		
		
		return persons;
	}

}
