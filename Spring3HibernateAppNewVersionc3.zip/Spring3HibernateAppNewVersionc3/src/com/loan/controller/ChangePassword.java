package com.loan.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.loan.bean.Registration;
import com.loan.bean.UsersBean;
import com.loan.model.Users;
import com.loan.service.RegistrationService;

@Controller
@RequestMapping("/changepassword")
public class ChangePassword {
	
	@Autowired
	private RegistrationService registrationService;
	
	@Autowired
	private RegistrationValidation registrationValidation;
	
	

	
	public void setRegistrationService(RegistrationService registrationService) {
		this.registrationService = registrationService;
	}


	public void setRegistrationValidation(RegistrationValidation registrationValidation) {
		this.registrationValidation = registrationValidation;
	}


	@RequestMapping(method=RequestMethod.GET)
	public String showChangePass(Map model) {
		Registration registration = new Registration();
		model.put("registration", registration);
		return "changepassword";
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public String processChange(@ModelAttribute("command") UsersBean usersBean,@Valid Registration registration,
			BindingResult result, HttpSession session) {
		String email = (String) session.getAttribute("email");
		System.out.println(email);
		
		Users users = prepareModel(usersBean);
		if (result.hasErrors()) {
			return "changepassword";
		}else {
		System.out.println(usersBean.getPassword());
			try {
				int rs = registrationService.changePassword(email, usersBean.getPassword());
				if(rs>0) {
					return "redirect:/loginform.html";
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return "changepassword";
	}


	private Users prepareModel(UsersBean usersBean) {
		Users users = new Users();
		users.setPassword(usersBean.getPassword());
		return users;
	}
	

}
