package com.loan.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.loan.bean.LoginForm;
import com.loan.model.Users;
import com.loan.service.UserService;

@Controller
@RequestMapping("loginform.html")
public class LoginController {

	@Autowired
	private UserService userService;
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(method = RequestMethod.GET)
	public String showForm(Map model, HttpServletRequest request) {
		LoginForm loginForm = new LoginForm();
		model.put("loginForm", loginForm);
		return "loginform";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String processForm(@Valid LoginForm loginForm, BindingResult result,
			Map model, HttpServletRequest request) {
		String url = request.getParameter("name");
		HttpSession session=request.getSession();
		System.out.println(url);
		
		if (result.hasErrors()) {
			return "loginform" ;
		}
		
		List<Users> list= null;
		boolean userExists = false;
		try
		{
			userExists = userService.checkLogin(loginForm.getEmail(),loginForm.getPassword());
			if(userExists){
				model.put("loginForm", loginForm);
				Users user = userService.getLogin(loginForm.getEmail(), loginForm.getPassword());
				session.setAttribute("user", user);
				if(loginForm.getEmail().equals("admin@admin.com")) {
					return "redirect:/applicationlist.html";
				}else
					return "redirect:/index.html";
			}else{
				result.rejectValue("email","invaliduser");
				return "loginform";
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return "loginform";
	}
	
	
	
}
