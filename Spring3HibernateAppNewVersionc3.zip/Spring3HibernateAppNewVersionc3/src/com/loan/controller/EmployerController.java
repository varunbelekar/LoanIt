package com.loan.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.bean.EmployerBean;
import com.loan.model.Employer;
import com.loan.service.EmployerService;


@Controller
public class EmployerController {
	
	@Autowired
	private EmployerService employerService;
	
		
	public void setEmployerService(EmployerService employerService) {
		this.employerService = employerService;
	}
	
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveEmployer(@ModelAttribute("command") EmployerBean employerBean, 
			BindingResult result,HttpServletRequest request) {
		
		Integer v = (Integer)request.getSession().getAttribute("id");
		employerBean.setId(v);
		
		
		Employer employer = prepareModel(employerBean);
		try
		{
			employerService.addEmployerService(employer);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("redirect:/addbank.html");
	}
	
	@RequestMapping(value="/listEmployer", method = RequestMethod.GET)
	public ModelAndView listEmployer() {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("employers", prepareListofBean(employerService.listEmployerService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("employerListForm", model);
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addEmployer(@ModelAttribute("command")  EmployerBean employerBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			model.put("employers",  prepareListofBean(employerService.listEmployerService()));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return new ModelAndView("addEmployerForm", model);
	}
	
	
	private Employer prepareModel(EmployerBean employerBean){
		Employer employer = new Employer();
		employer.setCemployerId(employerBean.getEmployerId());
		employer.setCemployerName(employerBean.getEmployerName());
		employer.setCemployerAddress(employerBean.getEmployerAddress());
		employer.setCemployerTelephone(employerBean.getEmployerTelephone());
		employer.setId(employerBean.getId());
		
		return employer;
	}
	
	
	private List<EmployerBean> prepareListofBean(List<Employer> employers){
		List<EmployerBean> beans = null;
		if(employers != null && !employers.isEmpty()){
			beans = new ArrayList<EmployerBean>();
			EmployerBean bean = null;
			for(Employer employer : employers){
				bean = new EmployerBean();
				bean.setEmployerId(employer.getCemployerId());
				bean.setEmployerName(employer.getCemployerName());
				bean.setEmployerAddress(employer.getCemployerAddress());
				bean.setEmployerTelephone(employer.getCemployerTelephone());
				bean.setId(employer.getId());
			
				beans.add(bean);
			}
		}
		return beans;
	}



}
