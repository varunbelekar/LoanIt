package com.loan.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@RequestMapping("/signout.html")
public class SignOutController {

	@RequestMapping(method=RequestMethod.GET)
	public String signout(HttpSession session) {
		session.invalidate();
		return "redirect:/index.html";
	}
	
	
}
