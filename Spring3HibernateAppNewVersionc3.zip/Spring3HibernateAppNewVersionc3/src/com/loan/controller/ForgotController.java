package com.loan.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.loan.bean.Registration;
import com.loan.bean.UsersBean;
import com.loan.model.Users;
import com.loan.service.RegistrationService;

@Controller
@RequestMapping("/forgotpassword.html")
public class ForgotController {

	@Autowired
	private RegistrationService registrationService;

	
	public void setRegistrationService(RegistrationService registrationService) {
		this.registrationService = registrationService;
	}
	
	
	@RequestMapping(method=RequestMethod.GET)
	public String showForgot(Map model) {
		Registration registration = new Registration();
		model.put("registration", registration);
		return "forgotpassword" ;
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String processRegistration(@ModelAttribute("command") UsersBean usersBean,@Valid Registration registration,
			BindingResult result, HttpSession session) {
		// set custom Validation by user
		Users users = prepareModelUser(usersBean);
	
		try {
			List<Users> list = registrationService.findUser(users.getEmail());
			//System.out.println(list.get(0).getEmail());
			if(!list.isEmpty()) {
				String email = list.get(0).getEmail();
				if(users.getQuestions().equals(list.get(0).getQuestions()) && users.getAnswer().equals(list.get(0).getAnswer())) {
						session.setAttribute("email", email);
						return "changepassword";
					}else {
						System.out.println(list.get(0).getQuestions() + " " + list.get(0).getAnswer());
						return "forgotpassword";
					}
			}else {
				System.out.println("empty");
			}
		}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	
		
		return "forgotpassword";
	
	}
	
	private Users prepareModelUser(UsersBean usersBean){
		Users users = new Users();
		
		users.setEmail(usersBean.getEmail());
		users.setAnswer(usersBean.getAnswer());
		users.setQuestions(usersBean.getQuestions());
		return users;
	}
	
	
}
