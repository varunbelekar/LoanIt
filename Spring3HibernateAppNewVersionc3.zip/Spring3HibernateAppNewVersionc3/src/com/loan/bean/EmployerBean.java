package com.loan.bean;

public class EmployerBean {
	
	private Integer employerId;
	private String employerName;
	private String employerAddress;
	private Long employerTelephone;
	private Integer id;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getEmployerId() {
		return employerId;
	}
	public void setEmployerId(Integer employerId) {
		this.employerId = employerId;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getEmployerAddress() {
		return employerAddress;
	}
	public void setEmployerAddress(String employerAddress) {
		this.employerAddress = employerAddress;
	}
	public Long getEmployerTelephone() {
		return employerTelephone;
	}
	public void setEmployerTelephone(Long employerTelephone) {
		this.employerTelephone = employerTelephone;
	}
	
	

}
