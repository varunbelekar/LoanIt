package com.loan.model;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employment")

public class Employment implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="employmentDetailsId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long cemploymentDetailsId;
	
	@Column(name="applyingAs")
	private String capplyingAs;
	
	@Column(name="salaried")
	private String csalaried;
	
	@Column(name="natureOfOrganization")
	private String cnatureOfOrganization;
	
	@Column(name="occupation")
	private String coccupation;
	
	@Column(name="designation")
	private String cdesignation;
	
	@Column(name="monthlyIncome")
	private Long cmonthlyIncome;
	
	@Column(name="id")
	private Integer id;
	
	

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public Long getCemploymentDetailsId() {
		return cemploymentDetailsId;
	}
	
	

	public Employment() {
	
	}
	



	public Employment(Long cemploymentDetailsId, String capplyingAs, String csalaried, String cnatureOfOrganization,
			String coccupation, String cdesignation, Long cmonthlyIncome) {
		
		this.cemploymentDetailsId = cemploymentDetailsId;
		this.capplyingAs = capplyingAs;
		this.csalaried = csalaried;
		this.cnatureOfOrganization = cnatureOfOrganization;
		this.coccupation = coccupation;
		this.cdesignation = cdesignation;
		this.cmonthlyIncome = cmonthlyIncome;
	}



	public String getCapplyingAs() {
		return capplyingAs;
	}



	public void setCapplyingAs(String capplyingAs) {
		this.capplyingAs = capplyingAs;
	}



	public String getCsalaried() {
		return csalaried;
	}



	public void setCsalaried(String csalaried) {
		this.csalaried = csalaried;
	}



	public String getCnatureOfOrganization() {
		return cnatureOfOrganization;
	}



	public void setCnatureOfOrganization(String cnatureOfOrganization) {
		this.cnatureOfOrganization = cnatureOfOrganization;
	}



	public String getCoccupation() {
		return coccupation;
	}



	public void setCoccupation(String coccupation) {
		this.coccupation = coccupation;
	}



	public String getCdesignation() {
		return cdesignation;
	}



	public void setCdesignation(String cdesignation) {
		this.cdesignation = cdesignation;
	}



	public Long getCmonthlyIncome() {
		return cmonthlyIncome;
	}



	public void setCmonthlyIncome(Long cmonthlyIncome) {
		this.cmonthlyIncome = cmonthlyIncome;
	}



	public void setCemploymentDetailsId(Long cemploymentDetailsId) {
		this.cemploymentDetailsId = cemploymentDetailsId;
	}

	
	
	
	
}


