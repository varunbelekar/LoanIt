package com.loan.model;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="documents")
public class Document {
	
	@Id
	@Column(name="did")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer did;
	
	@Column(name="name")
	private String name;
	
	
	
	@Column(name="filename")
	private String filename;
	
	@Column(name="content")
	@Lob
	private Blob content;
	
	@Column(name="contentType")
	private String contentType;
	
	@Column(name="id")
	private Integer id;
	

	

	public Integer getDid() {
		return did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Blob getContent() {
		return content;
	}

	public void setContent(Blob content) {
		this.content = content;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	
	
	
	
}
