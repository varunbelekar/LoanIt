package com.loan.service;

public interface UserService {
	public boolean checkLogin(String userName, String userPassword) throws Exception;
}
