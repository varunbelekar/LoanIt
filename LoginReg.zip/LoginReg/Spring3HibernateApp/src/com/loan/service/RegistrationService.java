package com.loan.service;

import com.loan.model.Users;

public interface RegistrationService {
	public void addUsers(Users user) throws Exception;
}
