package com.loan.dao;

import com.loan.model.Users;

public interface RegistrationDao {
	public void addUsers(Users user) throws Exception;
}
