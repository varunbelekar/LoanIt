package com.loan.service;

import com.loan.model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer) throws Exception;
}
