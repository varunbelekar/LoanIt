package com.loan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.CustomerDAO;
import com.loan.dao.RegistrationDAO;
import com.loan.model.Login;


@Service("registrationService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	private RegistrationDAO registrationDAO ;
	
	

	

	public void setRegistrationDAO(RegistrationDAO registrationDAO) {
		this.registrationDAO = registrationDAO;
	}





	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void addLogin(Login login) throws Exception {
		registrationDAO.addUsers(login);
	}

}
