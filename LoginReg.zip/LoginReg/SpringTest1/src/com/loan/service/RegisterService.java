package com.loan.service;


import com.loan.model.Login;

public interface RegisterService {
	public void addLogin(Login login) throws Exception;
}
