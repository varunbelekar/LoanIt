package com.loan.dao;

import com.loan.model.Customer;

public interface CustomerDAO {

	public void addCustomers(Customer customer) throws Exception;
}
