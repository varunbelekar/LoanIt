package com.loan.dao;

import com.loan.model.Login;

public interface RegistrationDAO {

	public void addUsers(Login user) throws Exception;
}
