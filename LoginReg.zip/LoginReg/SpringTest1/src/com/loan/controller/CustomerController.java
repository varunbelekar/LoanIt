package com.loan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.beans.CustomerBean;
import com.loan.model.Customer;
import com.loan.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public ModelAndView addCustomer(@ModelAttribute("command") CustomerBean customerBean, BindingResult result) {
		Customer customer = prepareModel(customerBean);
		try {
			customerService.addCustomer(customer);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("redirect:/index.jsp");
	}

	private Customer prepareModel(CustomerBean customerBean) {
		Customer customer = new Customer();
		customer.setId(customerBean.getId());
		customer.setName(customerBean.getName());
		customer.setCity(customerBean.getCity());
		customer.setEmail(customerBean.getEmail());
		customer.setMobile(customerBean.getMobile());
		return customer;
	}
}
