package com.loan.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.loan.beans.LoginBean;
import com.loan.beans.Registration;
import com.loan.model.Login;
import com.loan.service.RegisterService;

@Controller
@RequestMapping("/register.html")
public class RegisterController {

	@Autowired
	private RegisterService registerService;
	
	@Autowired
	private RegistrationValidation registrationValidation;

	public void setRegisterService(RegisterService registerService) {
		this.registerService = registerService;
	}
	

	public void setRegistrationValidation(RegistrationValidation registrationValidation) {
		this.registrationValidation = registrationValidation;
	}

	// Display the form on the get request




	@RequestMapping(method = RequestMethod.GET)
	public String showRegistration(Map model) {
		Registration registration = new Registration();
		model.put("registration", registration);
		return "register";
	}
	
	public String processRegistration(@ModelAttribute("command")LoginBean loginBean, @Valid Registration registration, BindingResult result) {
		
		Login login = prepareModel(loginBean);
		registrationValidation.validate(registration, result);
		if(result.hasErrors()) {
			return "register" ;
		}else
		{
			try
			{
				registerService.addLogin(login);
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		return "registrationSuccess";
	}

	private Login prepareModel(LoginBean loginBean) {
		Login login = new Login();
		login.setEmail(loginBean.getEmail());
		login.setPassword(loginBean.getPassword());
		return login;
	}
}
