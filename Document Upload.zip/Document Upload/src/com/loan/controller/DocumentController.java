package com.loan.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.loan.model.Document;
import com.loan.service.DocumentService;

@Controller
public class DocumentController {
	
	@Autowired
	private DocumentService documentService;

	public void setDocumentService(DocumentService documentService) {
		this.documentService = documentService;
	}

	@RequestMapping("/imageshow")
	public void showimage(@RequestParam("documentId") Integer documentId, HttpServletResponse response,HttpServletRequest request) 
	          throws ServletException, IOException,SQLException{
		Document doc = documentService.get(documentId);
		Blob blob = doc.getContent();

		int blobLength = (int) blob.length();  
		byte[] blobAsBytes = blob.getBytes(1, blobLength);

		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	    response.getOutputStream().write(blobAsBytes);


	    response.getOutputStream().close();
		//blob.free();
	}
	
	@RequestMapping("/indexdocument")
	public String index(Map<String, Object> map) {
		try {
			map.put("document", new Document());
			map.put("documentList", documentService.list());
		}catch(Exception e) {
			e.printStackTrace();
		}

		return "documents";
	}
	
	@RequestMapping("/documentlist")
	public String list(Map<String, Object> map){
		try{
			map.put("document", new Document());
			map.put("documentList", documentService.list());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return "documentlist";
	}
	
	@RequestMapping(value = "/savedocument", method = RequestMethod.POST)
	public String save(
			@ModelAttribute("document") Document document,
			@RequestParam("file") MultipartFile file) {
		
		
		/*System.out.println("Name:" + document.getName());
		System.out.println("Desc:" + document.getDescription());
		System.out.println("File:" + file.getName());
		System.out.println("ContentType:" + file.getContentType());*/
		
		try {
			Blob blob = Hibernate.createBlob(file.getInputStream());
			//byte[] blob = file.getBytes();
			document.setFilename(file.getOriginalFilename());
			document.setContent(blob);
			document.setContentType(file.getContentType());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			documentService.save(document);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/indexdocument.html";
	}

	@RequestMapping("/download/{documentId}")
	public String download(@PathVariable("documentId")
			Integer documentId, HttpServletResponse response) {
		
		Document doc = documentService.get(documentId);
		
		try {
			response.setHeader("Content-Disposition", "inline;filename=\"" +doc.getFilename()+ "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType(doc.getContentType());
			
			IOUtils.copy(doc.getContent().getBinaryStream(), out);
			
			out.flush();
			out.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}

	@RequestMapping("/remove/{documentId}")
	public String remove(@PathVariable("documentId")
			Integer documentId) {
		
		documentService.remove(documentId);
		
		return "redirect:/indexdocument.html";
	}
}

