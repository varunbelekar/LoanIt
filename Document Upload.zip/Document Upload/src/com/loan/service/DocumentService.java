package com.loan.service;

import java.util.List;

import com.loan.model.Document;

public interface DocumentService {

	public void save(Document document);
	
	
	public List<Document> list();
	
	
	public Document get(Integer id);

	
	public void remove(Integer id);
}
