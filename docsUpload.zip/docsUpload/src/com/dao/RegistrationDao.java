package com.dao;

import com.model.Users;

public interface RegistrationDao {
	public void addUsers(Users user) throws Exception;
}
