package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired(required=true)
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public void addEmployee(Employee employee) throws Exception {
		sessionFactory.getCurrentSession().saveOrUpdate(employee);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Employee> listEmployeess() throws Exception{
		return (List<Employee>) sessionFactory.getCurrentSession().createCriteria(Employee.class).list();
	}
	@Transactional
	public Employee getEmployee(int empid) throws Exception {
		return (Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
	}
	@Transactional
	public void deleteEmployee(Employee employee) throws Exception {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM Employee WHERE empid = "+employee.getEmpId()).executeUpdate();
		}
	

}