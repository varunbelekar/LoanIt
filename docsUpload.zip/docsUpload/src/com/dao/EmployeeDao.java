package com.dao;

import java.util.List;

import com.model.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee) throws Exception;

	public List<Employee> listEmployeess() throws Exception;
	
	public Employee getEmployee(int empid) throws Exception;
	
	public void deleteEmployee(Employee employee) throws Exception;
}
