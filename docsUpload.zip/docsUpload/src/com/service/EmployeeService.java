package com.service;

import java.util.List;

import com.model.Employee;

public interface EmployeeService {
	public void addEmployee(Employee employee) throws Exception;

	public List<Employee> listEmployeess() throws Exception;
	
	public Employee getEmployee(int empid) throws Exception;
	
	public void deleteEmployee(Employee employee) throws Exception;
}
