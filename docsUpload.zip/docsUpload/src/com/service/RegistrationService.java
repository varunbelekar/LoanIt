package com.service;

import com.model.Users;

public interface RegistrationService {
	public void addUsers(Users user) throws Exception;
}

