package com.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.dao.DocumentDao;
import com.model.Document;

@Controller
public class DocumentController {
	
	@Autowired
	private DocumentDao documentDao;
	public void setDocumentDao(DocumentDao documentDao) {
		this.documentDao = documentDao;
	}

	@RequestMapping("/imageshow")
	public void showimage(@RequestParam("documentId") Integer documentId, HttpServletResponse response,HttpServletRequest request) 
	          throws ServletException, IOException,SQLException{
		Document doc = documentDao.get(documentId);
		Blob blob = doc.getContent();

		int blobLength = (int) blob.length();  
		byte[] blobAsBytes = blob.getBytes(1, blobLength);

		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	    response.getOutputStream().write(blobAsBytes);


	    response.getOutputStream().close();
		//blob.free();
	}
	
	@RequestMapping("/indexdocument")
	public String index(Map<String, Object> map) {
		try {
			map.put("document", new Document());
			map.put("documentList", documentDao.list());
		}catch(Exception e) {
			e.printStackTrace();
		}

		return "documents";
	}
	
	@RequestMapping(value = "/savedocument", method = RequestMethod.POST)
	public String save(
			@ModelAttribute("document") Document document,
			@RequestParam("file") MultipartFile file) {
		
		
		/*System.out.println("Name:" + document.getName());
		System.out.println("Desc:" + document.getDescription());
		System.out.println("File:" + file.getName());
		System.out.println("ContentType:" + file.getContentType());*/
		
		try {
			Blob blob = Hibernate.createBlob(file.getInputStream());
			//byte[] blob = file.getBytes();
			document.setFilename(file.getOriginalFilename());
			document.setContent(blob);
			document.setContentType(file.getContentType());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			documentDao.save(document);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/indexdocument.html";
	}

	@RequestMapping("/download/{documentId}")
	public String download(@PathVariable("documentId")
			Integer documentId, HttpServletResponse response) {
		
		Document doc = documentDao.get(documentId);
		
		try {
			response.setHeader("Content-Disposition", "inline;filename=\"" +doc.getFilename()+ "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType(doc.getContentType());
			
			IOUtils.copy(doc.getContent().getBinaryStream(), out);
			
			out.flush();
			out.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}

	@RequestMapping("/remove/{documentId}")
	public String remove(@PathVariable("documentId")
			Integer documentId) {
		
		documentDao.remove(documentId);
		
		return "redirect:/indexdocument.html";
	}
}
